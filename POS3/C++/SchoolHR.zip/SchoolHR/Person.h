

#pragma once
#include <string>
#include "MyUtils.h"
#include "Date.h"

using namespace std;

class Person: public Date{

protected:
    string firstName;
    string lastName;
    int socSecNum;

public:
    Person(int d, int m, int y, const string& fN, const string& lN, int sSN);
    string toJSON() const;
    string getFirstName() const;
    string getLastName() const;
    int getSocSecNum() const;
    void setFirstName(const string& fN);
    void setLastName(const string& lN);
    int setsocSecNum(int sSN);

};
