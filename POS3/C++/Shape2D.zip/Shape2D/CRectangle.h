#pragma once
#include "CShape2D.h"
#include "CPoint2D.h"

class CRectangle : public CShape2D{

protected:
    CPoint2D lowerLeftPnt;
    float width;
    float height;

public:
    CRectangle(int r,int g,int b, int l, bool iF, float x, float y, float h, float w);
    string toString();
    friend ostream& operator<<(ostream& o, CRectangle& r);
    virtual void scale(int factor);
    virtual void move(int x, int y);
    virtual float calcShape();
    virtual int getQuadrant();

};

