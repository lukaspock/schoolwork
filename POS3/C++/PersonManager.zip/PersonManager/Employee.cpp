#include "Student.h"
#include "Employee.h"

Employee::Employee(string n, int s, int b)
{
    this->name = n;
    this->salary = s;
    this->birthyear = b;
}

Employee::Employee(const Employee &e)
{
    this->name = e.name;
    this->salary = e.salary;
    this->birthyear = e.birthyear;
}

void Employee::setName(const string n)
{
    this->name = n;
}
void Employee::setSal(const int s)
{
    this->salary = s;
}
void Employee::setBirthyear(const int b)
{
    this->birthyear = b;
}
string Employee::getName()
{
    return this->name;
}
int Employee::getSal()
{
    return this->salary;
}
int Employee::getBirthyear()
{
    return this->birthyear;
}

void Employee::show()
{
    cout << endl << endl << "Name: " << this->name;
    cout << endl << "Salary: " << this->salary;
    cout << endl << "Birthyear: " << this->birthyear;
}

int Employee::getAge(int currentYear)
{
    return currentYear - this->birthyear;
}
