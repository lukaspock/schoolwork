#include "person.h"
using namespace std;

void initPerson(Person &p, const int idm, const char* name)
{
    p.id = idm;
    strcpy(p.name, name);
}

void printPerson(Person p)
{
    cout << "Person: " << endl;
    cout << "Name: " << p.name << endl;
    cout << "Id: " << p.id << endl;
}

void printPerson(Person people[], const int num)
{
    for(int i=0; i<num; i++)
    {
        printPerson(people[i]);
    }
}
