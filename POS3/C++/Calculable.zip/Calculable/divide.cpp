#include "divide.h"

double Divide::calculate(double lVal, double rVal)const
{
    return lVal / rVal;
}

string Divide::getOperator()const
{
    return "/";
}
