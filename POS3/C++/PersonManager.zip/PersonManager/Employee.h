#include <iostream>
using namespace std;

class Employee{

private:
    string name;
    int salary;
    int birthyear;

public:
    Employee(string n = "Max" , int s = 1500 , int b = 2000);
    Employee(const Employee &e);

    void setName(const string n);
    void setSal(const int s);
    void setBirthyear(const int b);

    string getName();
    int getSal();
    int getBirthyear();

    void show();
    int getAge(int currentYear = 2025);
};


