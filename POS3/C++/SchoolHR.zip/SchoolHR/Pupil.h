
#pragma once
#include <string>
#include "Person.h"

using namespace std;

class Pupil: public Person{
private:

    string className;
public:
    Pupil(int d, int m, int y, const string& cN, const string& fN, const string& lN, int sSN);
    string getClassName() const;
    void setClassName(const string& cN);

    string toJSON() const;
};
