#pragma once
#include <iostream>
using namespace std;

class Product{

    private:
        int id;
        char name[30];
        double price;
        int shelf;

    public:
        Product(int id, char* name , double price, int shelf);
        int getId()const;
        void setId(const int id);
        char* getName();
        void setName(const char* name);
        double getPrice();
        void setPrice(const int price);
        int getShelf()const;
        void setShelf(int shelf);
        void show();
};
