#include <iostream>
#include "Pupil.h"
#include "Teacher.h"
#include "HeadofDepartment.h"

using namespace std;

int main()
{
    Teacher t1(1,2,3,"Gerhard", "Posch", 69, 69);
    Pupil p1(1,2,3,"3BHIF", "Justin", "Tatzgern", 68);
    HeadOfDepartment h1(1,2,3,"Thomas", "Gabriel", 69, 69, "Informatik");

    string s = p1.toJSON();

    cout << s << endl << endl;  // Ausgabe Pupil

    string s2 = t1.toJSON();

    cout << s2 << endl << endl; // Ausgabe Teacher

    string s3 = h1.toJSON();

    cout << s3; // Ausgabe headOfDepartment


}
