
#include "Date.h"

string Date::toJSON() const
{
    return " Day:" + MyUtils::toString(this->day) +
    " Month:" + MyUtils::toString(this->month) +
    " Year:" + MyUtils::toString(this->year);
}

void Date::setDay(int d)
{
    this->day = d;
}

void Date::setMonth(int m)
{
    this->month = m;
}

void Date::setYear(int y)
{
    this->year = y;
}

int Date::getDay()const
{
    return this->day;
}

int Date::getMonth()const
{
    return this->month;
}

int Date::getYear()const
{
    return this->year;
}
