#include <iostream>
#include "Person.h"
#include "PersonList.h"

using namespace std;

int main() {

    CPerson p1("Justin","Fortnite Street", 1, "Fortnite", "Fortnite", "Fortnite", 1, 2, 3);
    CPerson p2("Lukas","Altschlaining 121", 1, "Altschlaining", "Altschlaining", "Altschlaining", 4, 5, 6);

    //cout << "Details of the person:\n";
    //p1.show();

    CPersonList pList1;
    pList1.add(&p1);
    pList1.add(&p2);
    pList1.show();

    pList1.removeAt(1);
    pList1.show();


    return 0;
}
