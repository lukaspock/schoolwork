
#pragma once
#include <string.h>
#include <iostream>

typedef struct Person{

    int id;
    char name[16];
}Person, *PPerson;

void initPerson(Person &p, const int idm, const char* name);
void printPerson(Person p);
void printPerson(Person people[], const int num);
