
#pragma once
#include <iostream>
#include <cmath>

using namespace std;

class Point{
    private:
        int x;
        int y;
    public: // interface
        void setX(const int value);
        void setY(const int value);
        int getX()const;
        int getY()const;
        void print()const;
        double distanceTo(const Point &p)const;
};
