#include <iostream>
#include "include\StringedInstrument.h"
#include "Instrument.h"
#include "StringedInstrument.h"

using namespace std;

int main()
{
    string majorList[] = {"C", "G","A","B","F#"};
    char stringListGuitar[] = {'E','A','D','G','B','E'};
    char stringListBass[] = {'E','A','D','G'};

    StringedInstrument guitar1("Gibson", 5, majorList, 6, stringListGuitar);
    guitar1.print();
    cout << endl;
    StringedInstrument guitar2 = guitar1;
    guitar2.print();
    cout << endl;

    guitar2.setStringList(stringListBass,4);
    guitar2.print();
    cout << endl;

    StringedInstrument guitar3;
    cout << endl << "guitar3";
    guitar3.print();
    cout << endl;
    guitar3 = guitar1;
    guitar3.setName("Fender");
    guitar3.print();
    cout << endl;

    return 0;
}
