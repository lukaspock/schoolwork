#include "Fraction.h"
#include <cmath>
int berechneGGT(int a, int b);
int berechneKGV(int a, int b);
int shorten();

Fraction::Fraction(int num,int denom){
   numerator =num; denominator=denom;
   if (denominator<0){
      numerator =-num; denominator=-denom;
   }
}
Fraction Fraction::operator*(const Fraction &a) const{
   Fraction res(a.numerator * this->numerator, a.denominator * this->denominator);
   return res;
}
int Fraction::operator==(const Fraction &a) const{
    if((a.numerator == this->numerator) && (a.denominator == this->denominator))
        return 1; //gleich

   else{
        if(this->denominator != a.denominator)
    {
        int kgv = berechneKGV(this->denominator, a.denominator);
        cout << endl << "KGV: \t" << kgv;
        int hilfe1 = kgv / this->denominator;
        cout << endl << "Num: " << hilfe1 * this->numerator;
        int hilfe2 = kgv / a.denominator;
        cout << endl << "Num: " << hilfe2 * a.numerator;

        return (this->numerator*hilfe1 == a.numerator*hilfe2);
    }
    else
        return (this->numerator == a.numerator);
   }

}
Fraction Fraction::operator~(void) const{
   Fraction res(this->denominator,this->numerator);
   return res;
}
Fraction& Fraction ::operator++(void){ // unary prefix
   this->numerator = this->numerator + 1;
   return *this;
}
Fraction Fraction ::operator++(int dummy){ // unary postfix
   Fraction help(*this);
   this->numerator = this->numerator + 1;
   return help;
}
Fraction Fraction::operator+(const Fraction &a)const{

    Fraction f;

    if(this->denominator != a.denominator)
    {
        int kgv = berechneKGV(this->denominator, a.denominator);
        cout << endl << "KGV: \t" << kgv;
        int hilfe1 = kgv / this->denominator;
        cout << endl << "Num: " << hilfe1 * this->numerator;
        int hilfe2 = kgv / a.denominator;
        cout << endl << "Num: " << hilfe2 * a.numerator;

        f.numerator = (this->numerator*hilfe1 + a.numerator*hilfe2);
        f.denominator = kgv;


    }
    else{
        f.numerator = (this->numerator + a.numerator);
        f.denominator = this->denominator;
   }

   int ggt = berechneGGT(f.numerator, f.denominator);
    f.numerator = f.numerator / ggt;
    f.denominator = f.denominator / ggt;

    return f;
}
Fraction Fraction::operator-(const Fraction &a)const{
    Fraction f;

    if(this->denominator != a.denominator)
    {
        int kgv = berechneKGV(this->denominator, a.denominator);
        cout << endl << "KGV: \t" << kgv;
        int hilfe1 = kgv / this->denominator;
        cout << endl << "Num: " << hilfe1 * this->numerator;
        int hilfe2 = kgv / a.denominator;
        cout << endl << "Num: " << hilfe2 * a.numerator;

        f.numerator = (this->numerator*hilfe1 - a.numerator*hilfe2);
        f.denominator = kgv;
    }
    else{
        f.numerator = (this->numerator - a.numerator);
        f.denominator = this->denominator;
   }

   int ggt = berechneGGT(f.numerator, f.denominator);
    f.numerator = f.numerator / ggt;
    f.denominator = f.denominator / ggt;

    return f;
}
void Fraction::show(){

    cout << endl << endl << "Num:\t" << this->numerator;
    cout << endl << "Denom:\t" << this->denominator;
}
Fraction Fraction::operator/(const Fraction &a) const{
   Fraction res(this->numerator / a.numerator, this->denominator / a.denominator);
   return res;
}
int Fraction::operator<(const Fraction &a) const{

    if(this->denominator != a.denominator)
    {
        int kgv = berechneKGV(this->denominator, a.denominator);
        cout << endl << "KGV: \t" << kgv;
        int hilfe1 = kgv / this->denominator;
        cout << endl << "Num: " << hilfe1 * this->numerator;
        int hilfe2 = kgv / a.denominator;
        cout << endl << "Num: " << hilfe2 * a.numerator;

        return (this->numerator*hilfe1 < a.numerator*hilfe2);
    }
    else
        return (this->numerator < a.numerator);
}
int Fraction::operator>(const Fraction &a) const{

    if(this->denominator != a.denominator)
    {
        int kgv = berechneKGV(this->denominator, a.denominator);
        cout << endl << "KGV: \t" << kgv;
        int hilfe1 = kgv / this->denominator;
        cout << endl << "Num: " << hilfe1 * this->numerator;
        int hilfe2 = kgv / a.denominator;
        cout << endl << "Num: " << hilfe2 * a.numerator;

        return (this->numerator*hilfe1 > a.numerator*hilfe2);
    }
    else
        return (this->numerator > a.numerator);
}
int Fraction::operator<=(const Fraction &a) const{

        if( (a.numerator == this->numerator) && (a.denominator == this->denominator))
            return 1;


        if(this->denominator != a.denominator)
    {
        int kgv = berechneKGV(this->denominator, a.denominator);
        cout << endl << "KGV: \t" << kgv;
        int hilfe1 = kgv / this->denominator;
        cout << endl << "Num: " << hilfe1 * this->numerator;
        int hilfe2 = kgv / a.denominator;
        cout << endl << "Num: " << hilfe2 * a.numerator;

        return (this->numerator*hilfe1 <= a.numerator*hilfe2);
    }
    else
        return (this->numerator <= a.numerator);

}
int Fraction::operator>=(const Fraction &a) const{

        if( (a.numerator == this->numerator) && (a.denominator == this->denominator))
            return 1;

        if(this->denominator != a.denominator)
    {
        int kgv = berechneKGV(this->denominator, a.denominator);
        cout << endl << "KGV: \t" << kgv;
        int hilfe1 = kgv / this->denominator;
        cout << endl << "Num: " << hilfe1 * this->numerator;
        int hilfe2 = kgv / a.denominator;
        cout << endl << "Num: " << hilfe2 * a.numerator;

        return (this->numerator*hilfe1 >= a.numerator*hilfe2);
    }
    else
        return (this->numerator >= a.numerator);


}
int Fraction::operator!=(const Fraction &a) const{
   if((a.numerator != this->numerator) && (a.denominator != this->denominator))
        return 1; //ungleich

   else{
        if(this->denominator != a.denominator)
    {
        int kgv = berechneKGV(this->denominator, a.denominator);
        cout << endl << "KGV: \t" << kgv;
        int hilfe1 = kgv / this->denominator;
        cout << endl << "Num: " << hilfe1 * this->numerator;
        int hilfe2 = kgv / a.denominator;
        cout << endl << "Num: " << hilfe2 * a.numerator;

        return (this->numerator*hilfe1 != a.numerator*hilfe2);
    }
    else
        return (this->numerator != a.numerator);
   }
}
Fraction& Fraction ::operator--(void){ // unary prefix
   this->numerator = this->numerator - 1;
   return *this;
}
Fraction Fraction ::operator--(int dummy){ // unary postfix
   Fraction help(*this);
   this->numerator = this->numerator - 1;
   return help;
}
int berechneGGT(int a, int b) {
    while (b != 0) {
        int rest = a % b;
        a = b;
        b = rest;
    }
    return a;
}
int berechneKGV(int a, int b) {
    int ggt = berechneGGT(a, b);
    return std::abs(a * b) / ggt; // |a * b| / ggT
}
