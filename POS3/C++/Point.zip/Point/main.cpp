#include <iostream>
#include "Point.h"
using namespace std;

int main()
{
   Point p1;

   p1.setX(5);
   p1.setY(7);

   cout << endl << "Ausgabe von p1:" << endl ;
   p1.print();

   Point p2;

   p2.setX(7);
   p2.setY(9);

   cout << endl << "Ausgabe von p2:" << endl ;
   p2.print();

   double erg = p1.distanceTo(p2);

   cout << endl << "ergebnis von distance to:" << endl << erg;

    return 0;
}
