
//Add Circle
#include "MenuContainer.h"


AddRectangle::AddRectangle(CShape2DList* p)
{
    this->ptr = p;
}

char* AddRectangle::getText()
{
    return "2. Add a Rectangle";
}

char AddRectangle::getShortCut()
{
    return '2';
}

void AddRectangle::execute()
{
    system("cls");

    int r,g,b,l,x,y;
    bool iF;
    float h,w;

    cout << endl << "Enter Parameters for the Rectangle:" << endl << endl;
    cout << "Color:" << endl;
    cout << "Red: ";
    cin >> r;
    cout << "Green: ";
    cin >> g;
    cout << "Blue: ";
    cin >> b;
    cout << endl << "Line(1,2,3):  ";
    cin >> l;
    cout << "Is Filled (1 or 0): ";
    cin >> iF;
    if(iF != 0 && iF != 1)
    {
        return;
    }
    cout << endl <<"Point: " << endl;
    cout << "X Value: ";
    cin >> x;
    cout << "Y Value: ";
    cin >> y;
    cout << endl << "Height: ";
    cin >> h;
    cout << "Width: ";
    cin >> w;

    CRectangle* rec = new CRectangle(r,g,b,l,iF,x,y,h,w);

    this->ptr->addShape(rec);
}

