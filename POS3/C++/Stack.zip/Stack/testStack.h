#pragma once
#include "Stack.h"

void testStackPush(const int elements[], int noe); //xpct == elements
void testStackIsEmpty(const int elements[], int noe, int numberOfPop, bool xpct);
void testStackIsFull (const int elements[], int noe, int numberOfPop, bool xpct);
