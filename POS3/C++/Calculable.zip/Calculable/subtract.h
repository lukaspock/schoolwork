
#pragma once
#include "Calculable.h"

class Subtract : public Calculable{

public:
    virtual double calculate(double lVal, double rVal)const;
    virtual string getOperator()const;
};
