
#include <iostream>
using namespace std;

class Student{

private:
    string name;
    string form;
    int birthyear;

public:
    Student(string n = "Max" , string f = "3BHIF", int b = 2000);
    Student(const Student &s);

    void setName(const string n);
    void setForm(const string f);
    void setBirthyear(const int b);

    string getName();
    string getForm();
    int getBirthyear();

    getAge(int currentYear = 2025);
    void show();

};


