
#include "CColor.h"

CColor::CColor(int r, int g, int b):red(r), green(g), blue(b)
{
    if(r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255 )
    {
        cout << "error, invalid parameters";
        this->red = 0;
        this->green = 0;
        this->blue = 0;
    }
}

const CColor CColor::RED (255, 0, 0);
const CColor CColor::GREEN (0, 255, 0);
const CColor CColor::BLUE (0, 0, 255);
const CColor CColor::BLACK (0, 0, 0);
const CColor CColor::WHITE (255, 255, 255);

string CColor::toString()
{
    return "Red: " + std::to_string(this->red) + "\n" + "Green: " + std::to_string(this->green) + "\n" + "Blue: " + std::to_string(this->blue) + "\n\n";
}

ostream& operator<<(ostream& o, CColor c)
{
    o << endl << "red: " << c.red << endl << "green: " << c.green << endl << "blue: " << c.blue << endl;
}


