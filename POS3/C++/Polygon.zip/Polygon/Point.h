
typedef struct Point *PPoint;

PPoint Point_create(int x, int y);
void Point_print(PPoint _this);
int Point_getDataSize();
int Point_isEqualCoord(PPoint _this, int point[2]);
int Point_isEqual(PPoint _this, PPoint point);
void Point_delete(PPoint _this);
