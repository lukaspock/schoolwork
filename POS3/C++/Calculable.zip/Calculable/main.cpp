#include "Calculable.h"
#include "add.h"
#include "multiply.h"
#include "subtract.h"
#include "divide.h"

#include <iomanip>
#include <cmath>

using namespace std;

void printOperations(const Calculable &calculation);

int main()
{
    Add a;
    Multiply m;
    Subtract s;
    Divide d;

    cout << endl << "Addition" << endl;
    printOperations(a);
    cout << endl << "Multiply" << endl;
    printOperations(m);
    cout << endl << "Subtract" << endl;
    printOperations(s);
    cout << endl << "Divide" << endl;
    printOperations(d);

}

void printOperations(const Calculable &calculation)
{
    for(int i = 1; i <= 10; i++)
    {
        for(int j = 1; j <= 10; j++)
        {
            cout << i << " " << calculation.getOperator() << " " << j << " = " << fixed << setprecision(2) << calculation.calculate(i,j) << "\t" ;
        }
        cout << endl;
    }

    cout << endl;
}
