#ifndef STRINGEDINSTRUMENT_H
#define STRINGEDINSTRUMENT_H

#include "Instrument.h"
#include "String.h"
#include <iostream>

using namespace std;


class StringedInstrument : protected Instrument
{
    public:
        StringedInstrument(string n = "", int noM = 0, string* majorList = nullptr, int nOS = 0, char* sL = nullptr);
        ~StringedInstrument();
        StringedInstrument(const StringedInstrument& other);
        StringedInstrument& operator=(const StringedInstrument& other);

        int getnumberOfStrings() { return numberOfStrings; }
        void setnumberOfStrings(int val) { numberOfStrings = val; }
        char* getStringList() { return stringList; }
        void setStringList(char* sL, int nOS);
        void copy(const StringedInstrument& other);
        void print();
        void setName(string n);

    protected:

    private:
        int numberOfStrings;
        char* stringList;
};

#endif // STRINGEDINSTRUMENT_H
