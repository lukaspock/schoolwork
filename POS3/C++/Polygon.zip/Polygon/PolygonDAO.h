
#include "Polygon.h"

typedef struct PolygonDAO *PPolygonDAO;

PPolygonDAO PolygonDAO_create(char *filename);
void PolygonDAO_writePolygon(PPolygonDAO _this, PPolygon polygon);
void PolygonDAO_writePolygonList(PPolygonDAO _this, PPolygon polygonList[], int noe);
PPolygon PolygonDAO_readFirstPolygon(PPolygonDAO _this);
PPolygon PolygonDAO_readPolygonAt(PPolygonDAO _this, int index);
PPolygon* PolygonDAO_readAll(PPolygonDAO _this, int *noe);
void PolygonDAO_updatePolygonAt(PPolygonDAO _this, int index, PPolygon newPolygon);
void PolygonDAO_delete(PPolygonDAO _this);
