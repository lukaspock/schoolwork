#pragma once
#include <iostream>
#include "string.h"
using namespace std;

class CColor {

protected:
    int red;        // 0 - 255
    int green;      // 0 - 255
    int blue;       // 0 - 255

public:
    static const CColor RED, GREEN, BLUE, BLACK, WHITE;
    CColor(int r = 0, int g = 0, int b = 0);
    string toString();
    friend ostream& operator<<(ostream& o, CColor c);
};
