
#pragma once
#include "MyUtils.h"
using namespace std;

class Date{

protected:
    int day;
    int month;
    int year;

public:
    Date(int d, int m, int y): day(d), month(m), year(y) {};
    string toJSON() const;
    void setDay(int d);
    void setMonth(int m);
    void setYear(int y);
    int getDay()const;
    int getMonth()const;
    int getYear()const;

};
