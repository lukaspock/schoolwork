#include "Calculable.h"

printOperations(const Calculable &calculation)
{

}
