#pragma once
#include "CCircle.h"
#include "CRectangle.h"


CRectangle::CRectangle(int r,int g,int b, int l, bool iF, float x, float y, float h, float w)
:CShape2D(r,g,b,l,iF), lowerLeftPnt(x,y), height(h), width(w) {}

string CRectangle::toString()
{
    string str = this->color.toString();
    str += "\nLine: " + std::to_string(this->line) + "\nIsFilled: " + std::to_string(this->isFilled);
    str += lowerLeftPnt.toString();
    str += "\nheight: " + std::to_string(this->height) + "\nwidth: " + std::to_string(this->width);

    return str;
}

ostream& operator<<(ostream& o, CRectangle& r)
{
    return o << r.toString();
}

void CRectangle::scale(int factor)
{
    this->height = this->height * factor;
    this->width = this->width * factor;
}

void CRectangle::move(int xV, int yV)
{
    this->lowerLeftPnt.setX(this->lowerLeftPnt.getX() + xV);
    this->lowerLeftPnt.setY(this->lowerLeftPnt.getY() + yV);
}

float CRectangle::calcShape()
{
    return this->height * this->width;
}

int CRectangle::getQuadrant()
{
    return this->lowerLeftPnt.getQuadrant();
}

