#pragma once
#include "CShape2D.h"
#include "CPoint2D.h"

class CCircle : public CShape2D
{
protected:
    CPoint2D point;
    float radius;

public:
    CCircle(int r,int g,int b, int l, bool iF, int x, int y, float rad);
    string toString();
    friend ostream& operator<<(ostream& o, CCircle& c);
    virtual void scale(int factor);
    virtual void move(int xV, int yV);
    virtual float calcShape();
    virtual int getQuadrant();
};
