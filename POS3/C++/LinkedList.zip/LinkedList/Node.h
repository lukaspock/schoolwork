#pragma once
#include <iostream>
using namespace std;

class Node{

    private:
        Node* next;
        int data;

    public:
        Node(int data);
        Node(const Node& n);
        ~Node();
        Node* getNext()const;
        void setNext(Node*);
        int getData()const;
        void setData(int data);
        void show();
};
