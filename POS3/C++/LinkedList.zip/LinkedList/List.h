
#pragma once
#include <iostream>
using namespace std;
#include "Node.h"

class List{

private:
    Node* begin;
public:
    List();
    List(const List& l);
    ~List();
    void addFront(int data);
    void addBack(int data);
    Node* getBegin()const;
    bool contains(int data);
    void print();
};
