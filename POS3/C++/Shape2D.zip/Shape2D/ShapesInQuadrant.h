
#include "menu.h"
class ShapesInQuadrant : public MenuItem{

private:
    CShape2DList* ptr;

public:
    ShapesInQuadrant(CShape2DList* p);
    virtual char* getText();
    virtual char getShortCut();
    virtual void execute();
};
