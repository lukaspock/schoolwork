#include "Point.h"
typedef struct Polygon *PPolygon;


PPolygon Polygon_create(int pl[][2], int noe);
void Polygon_deletePointAt(PPolygon _this, int index);
int Polygon_getNoe(PPolygon _this);
PPoint Polygon_getPointAt(PPolygon _this, int index);
void Polygon_addPoint(PPolygon _this, PPoint point);
void Polygon_insertPointAt(PPolygon _this, PPoint point, int index);
void Polygon_print(PPolygon _this);
int Polygon_getDataSize(PPolygon _this);
