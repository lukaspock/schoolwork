
#include "MenuContainer.h"


ScaleShapes::ScaleShapes(CShape2DList* p)
{
    this->ptr = p;
}

char* ScaleShapes::getText()
{
    return "4. Scale a Shape";
}

char ScaleShapes::getShortCut()
{
    return '4';
}

void ScaleShapes::execute()
{
    system("cls");

    int idx, f;
    cout << endl << endl << "What shape do you want to scale?" << endl;
    cin >> idx;
    idx--;
    cout << "Factor: ";
    cin >> f;

    this->ptr->getList()[idx]->scale(f);


}
