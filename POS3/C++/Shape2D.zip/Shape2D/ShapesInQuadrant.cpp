

//Add Circle
#include "MenuContainer.h"

ShapesInQuadrant::ShapesInQuadrant(CShape2DList* p)
{
    this->ptr = p;
}

char* ShapesInQuadrant::getText()
{
    return "8. GET NUMBER OF SHAPES IN QUADRANTS";
}

char ShapesInQuadrant::getShortCut()
{
    return '8';
}

void ShapesInQuadrant::execute()
{
    system("cls");

    int q;
    cout << endl << endl << "What Qaudrant do you want to check?" << endl;
    cin >> q;

    int count = 0;
    for(int i = 0; i < this->ptr->getNoe(); i++)
    {
        if(this->ptr->getList()[i]->getQuadrant() == q)
        {
            count++;
        }
    }
    cout << "Number Of Shapes: " << count;
}
