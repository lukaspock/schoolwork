
#include "testPoint.h"

void testPoint_print(PPoint _this)
{
    Point_print(_this);
}


void testPoint_getDataSize()
{
    int erg = Point_getDataSize();         // Datasize von Point
    printf("\n\nsize von Point:\n%d", erg);// Ausgabe Datasize zum Testen
}


void testPoint_isEqualCoord(PPoint _this, int point[2])
{

    int erg = Point_isEqualCoord(_this,  point);
    printf("\n\nRV von Point is Equal Coord:\n%d", erg);
}


void testPoint_isEqual(PPoint _this, PPoint point)
{
    int erg = Point_isEqual(_this, point);
    printf("\n\nRV von Point is Equal:\n%d", erg);
}

void testPoint_delete(PPoint _this)
{
    Point_delete(_this);
}
