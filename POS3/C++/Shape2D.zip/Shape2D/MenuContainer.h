#pragma once
#include "CShape2DList.h"
#include "menu.h"
#include "AddCircle.h"
#include "AddRectangle.h"
#include "ShowShapes.h"
#include "ScaleShapes.h"
#include "MoveShape.h"
#include "TotalAreaShape.h"
#include "getQuadrantShape.h"
#include "ShapesInQuadrant.h"

class MenuContainer {

private:
    MenuItem **menuList;
    int noe;

public:

    MenuContainer();
    MenuContainer(const MenuContainer& orig);
    virtual ~MenuContainer();
    MenuContainer& operator=(const MenuContainer& orig);

    void addMenuItem(MenuItem* item);
    void showMenus();
    void executeMenuItem(char shortcut);

};
