
#pragma once
#include <string>

using namespace std;

class MyUtils {
public:
    static string toString(int l);
};
