
#include "Node.h"

    Node::Node(int data)
    {
        this->next = nullptr;
        this->data = data;
    }

    Node::Node(const Node& n)
    {
        int d = n.data;
        Node* n1 = n.next;

        this->setData(d);
        this->setNext(n1);
    }

    Node::~Node()
    {
        delete this;
    }

    Node* Node::getNext()const
    {
        return this->next;
    }

    void Node::setNext(Node* node)
    {
        this->next = node;
    }

    int Node::getData()const
    {
        return this->data;
    }

    void Node::setData(int data)
    {
        this->data = data;
    }

    void Node::show()
    {
        //cout << "NEXT: " << this->getNext() << endl;
        cout << "DATA: " << this->getData() << endl;
    }



