#include "testStack.h"

void testStackPush(const int elements[], int noe) //xpct == elements
{
    cout << "TEST STACK PUSH";

    Stack s;

    for(int i=0; i<noe; i++)
    {
        s.push(i);
    }

    s.print();

    cout << endl <<"Expected:" << endl;

    for(int i=0; i<noe; i++)
    {
        cout << elements[i] << ", ";
    }

    cout << endl << endl;
}
void testStackIsEmpty(const int elements[], int noe, int numberOfPop, bool xpct)
{

    cout << "TEST STACK IS EMPTY";

    Stack s;

    for(int i=0; i<noe; i++)
    {
        s.push(elements[i]);
    }

    for(int i=0; i<numberOfPop; i++)
    {
        s.pop();
    }

    s.print();

    cout << endl << endl;

    int help = s.isEmpty();

    if(help == xpct)
    {
        cout << "test Stack is empty succesfull!" << endl;
    }
}

void testStackIsFull (const int elements[], int noe, int numberOfPop, bool xpct)
{
    cout << endl << "TEST STACK IS FULL";

    Stack s;

    for(int i=0; i<noe; i++)
    {
        s.push(elements[i]);
    }

    for(int i=0; i<numberOfPop; i++)
    {
        s.pop();
    }

    s.print();

    cout << endl;

    int help = s.isFull();



    if( xpct == help)
    {
        cout << "Stack is Full succesfull!" <<endl;
    }
}
