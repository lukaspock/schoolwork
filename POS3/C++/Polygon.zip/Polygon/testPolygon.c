#include "testPolygon.h"

struct Polygon{
    PPoint *array;
};

void testPolygon_addPoint(int pl[][2], int noe, int pointToAdd[2], int expected[][2])
{
    ;
}


void testPolygon_insertPointAt(int pl[][2], int noe, int pointToInsert[2], int index, int expected[][2])
{
    ;
}

void testPolygon_deletePointAt(int pl[][2], int noe, int index, int expected[][2])
{
    ;
}

