

#include "MenuContainer.h"


MoveShape::MoveShape(CShape2DList* p)
{
    this->ptr = p;
}

char* MoveShape::getText()
{
    return "5. Move a Shape";
}

char MoveShape::getShortCut()
{
    return '5';
}

void MoveShape::execute()
{

    system("cls");
    int idx, x, y;
    cout << endl << endl << "What Shape do you want to move?" << endl;
    cin >> idx;
    idx--;
    cout << "X Value: ";
    cin >> x;
    cout << "Y Value: ";
    cin >> y;
    this->ptr->getList()[idx]->move(x,y);

}

