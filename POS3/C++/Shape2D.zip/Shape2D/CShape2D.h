#pragma once
#include <iostream>
#include "CColor.h"
using namespace std;

class CShape2D {

protected:
    CColor color;
    int line;
    bool isFilled;

public:
    CShape2D(int r = 0,int g = 0,int b = 0, int l = 0, bool iF = 0);

    virtual string toString() = 0;
    friend ostream& operator<<(ostream& o, CShape2D& s);
    virtual void scale(int factor) = 0;
    virtual void move(int x, int y) = 0;
    virtual float calcShape() = 0;
    virtual int getQuadrant() = 0;
    virtual ~CShape2D(){}
};
