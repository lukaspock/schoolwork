#include "Fraction.h"


void testOperatorMultiply(int num1, int denom1, int num2, int denom2);
void testOperatorEqual(int num1, int denom1, int num2, int denom2);
void testOperatorReciprocal(int num, int denom);
void testOperatorPrefixIncrement(int num, int denom);
void testOperatorPostfixIncrement(int num, int denom);
void testOperatorAdd(int num1, int denom1, int num2, int denom2);
void testOperatorSubtract(int num1, int denom1, int num2, int denom2);
void testOperatorDivide(int num1, int denom1, int num2, int denom2);
void testOperatorLessThan(int num1, int denom1, int num2, int denom2);
void testOperatorGreaterThan(int num1, int denom1, int num2, int denom2);
void testOperatorLessThanOrEqual(int num1, int denom1, int num2, int denom2);
void testOperatorGreaterThanOrEqual(int num1, int denom1, int num2, int denom2);
void testOperatorNotEqual(int num1, int denom1, int num2, int denom2);
void testOperatorPrefixDecrement(int num, int denom);
void testOperatorPostfixDecrement(int num, int denom);
void testShorten(int num, int denom);
