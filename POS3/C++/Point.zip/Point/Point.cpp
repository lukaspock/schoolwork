
#include "Point.h"

void Point::setX(const int value){
   x = value;
}
void Point::setY(const int value){
   y = value;
}
int Point::getX() const {
   return x;
}
int Point::getY() const {
   return y;
}

void Point::print() const{
    cout << "x: " << x << endl;
    cout << "y: " << y << endl;
}

double Point::distanceTo(const Point &p)const{
    int a, b;
    double c;

    a = abs(x - (p.x));
    b = abs(y - (p.y));

    c = sqrt((a*a + b*b));

    return c;

}
