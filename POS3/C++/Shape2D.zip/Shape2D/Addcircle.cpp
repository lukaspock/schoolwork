
//Add Circle
#include "MenuContainer.h"

AddCircle::AddCircle(CShape2DList* p)
{
    this->ptr = p;
}

char* AddCircle::getText()
{
    return "1. Add a Circle";
}

char AddCircle::getShortCut()
{
    return '1';
}

void AddCircle::execute()
{
    system("cls");

    int r,g,b,l,x,y;
    bool iF;
    float rad;

    cout << endl << "Enter Parameters for the Circle:" << endl << endl;
    cout << "Color:" << endl;
    cout << "Red: ";
    cin >> r;
    cout << "Green: ";
    cin >> g;
    cout << "Blue: ";
    cin >> b;
    cout << endl << "Line(1,2,3):  ";
    cin >> l;
    cout << "Is Filled (1 or 0): ";
    cin >> iF;
    if(iF != 0 && iF != 1)
    {
        return;
    }
    cout << endl <<"Point: " << endl;
    cout << "X Value: ";
    cin >> x;
    cout << "Y Value: ";
    cin >> y;
    cout << endl << "Radius: ";
    cin >> rad;

    CCircle* c = new CCircle(r,g,b,l,iF,x,y,rad);

    this->ptr->addShape(c);
}
