
#include "MyString.h"

MyString::MyString(const char *cStr)
{
    this->str = new char[strlen(cStr)+1];
    strcpy(this->str, cStr);
}

MyString::MyString(const MyString &s)
{
    this->str = new char[strlen(s.str)+1];
    strcpy(this->str, s.str);
}

MyString MyString::operator=(const MyString &s)
{
    if(this != &s)
    {
        delete[] this->str;
        this->str = new char[strlen(s.str)];
        strcpy(this->str,s.str);
    }

    return *this;
}

MyString::~MyString()
{
    delete[] this->str;
}

int MyString::getLength() const
{
    return strlen(this->str);
}

void MyString::show()
{
    cout << endl << this->str;
}

void MyString::append(const MyString &str)
{
    int length = this->getLength() + str.getLength() + 1;
    int length2 = this->getLength();
    char *temp = new char[length];

    strcpy(temp, this->str);

    strcpy(&(temp[length2]), str.str);

    delete[] this->str;
    this->str = temp;
}

void MyString::addChar(char ch)
{
    int length = this->getLength() + 1;
    char *temp = new char[length+1];

    strcpy(temp, this->str);

    temp[length - 1] = ch;
    temp[length] = '\0';

    delete[] this->str;
    this->str = temp;


}

char MyString::getCharAt(int idx)
{
    if(idx <= 0 || idx >= this->getLength())
    {
        return NULL;

    }
    return this->str[idx];

}

int MyString::compare(const MyString &str)
{
    return strcmp(this->str, str.str);
}

void MyString::toUpper()
{
    for(int i=0; i < this->getLength(); i++)
    {
        if(this->str[i] <= 122 && this->str[i] >= 97)
        {
            this->str[i] = this->str[i] - 32;
        }
    }
}

void MyString::toLower()
{
    for(int i=0; i < this->getLength(); i++)
    {
        if(this->str[i] <= 90 && this->str[i] >= 65)
        {
            this->str[i] = this->str[i] + 32;
        }
    }
}

void MyString::insertCharAt(char ch, int idx)
{
    int length = this->getLength() + 1;
    char *temp = new char[length+1];

    strcpy(temp, this->str);


    for(int i=length; i>idx; i--)
    {
        temp[i] = temp[i-1];
    }

    temp[idx] = ch;
    temp[length] = '\0';

    delete[] this->str;
    this->str = temp;
}

void MyString::insertStrAt(const MyString &str, int idx)
{
    int length2 = str.getLength();
    int length = this->getLength() + length2;
    char *temp = new char[length+1];

    strcpy(temp, this->str);


    for(int i=0; i<length2; i++)
    {
        for(int i=length; i>idx; i--)
        {
            temp[i] = temp[i-1];
        }

    }

    for(int i=0; i<length2; i++)
    {
        temp[idx+i] = str.str[i];
    }


    temp[length] = '\0';

    delete[] this->str;
    this->str = temp;
}

MyString MyString::operator+(const MyString &str)
{
    cout << endl << "operator +" << endl;

    MyString temp(this->str);
    temp.append(str);

    return temp;
}

MyString MyString::operator++()
{
    cout << endl << "operator ++ pre" << endl;

    this->addChar('*');

    return *this;
}

MyString MyString::operator++(int dummy)
{
    cout << endl << "operator ++ post" << endl;

    MyString temp = this->str;

    this->addChar('*');

    return temp;
}

MyString MyString::operator/(int index)
{
    int length = this->getLength();

    char* temp;

    temp = new char[length];

    strcpy(temp, this->str);

    for(int i = index; i < length ; i++)
    {
        temp[i] = temp[i+1];
    }

    temp[length] = '\0';

    delete[] this->str;

    this->str = temp;

    return *this;
}

