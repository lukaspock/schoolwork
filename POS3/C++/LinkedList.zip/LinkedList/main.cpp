#include <iostream>
#include "Node.h"
#include "List.h"

using namespace std;

int main()
{
    List l;

    l.addFront(4);
    l.addFront(3);
    l.addFront(2);
    l.addFront(1);
    l.addBack(5);
    l.print();

    List l2 = l;

    cout << endl << endl << endl << "Ausgabe l2 (copyconstructor) " << endl << endl << endl ;
    l2.print();


    return 0;
}
