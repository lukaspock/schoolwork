
#include "Polygon.h"
#include "Point.h"

struct Polygon{
    PPoint *array;
    int noe;
};

PPolygon Polygon_create(int pl[][2], int noe)
{
    PPolygon _this;

    _this = (PPolygon)malloc(sizeof(struct Polygon));
    _this->array = (PPoint *)malloc(sizeof(PPoint) * noe);

    for(int i=0; i<noe; i++)
    {
        _this->array[i] = Point_create(pl[i][0], pl[i][1]);
    }

    _this->noe = noe;

    return _this;

}

void Polygon_deletePointAt(PPolygon _this, int index)
{
    Point_delete(_this->array[index]);
    _this->noe = _this->noe - 1;
}

int Polygon_getNoe(PPolygon _this)
{
    return _this->noe;
}

PPoint Polygon_getPointAt(PPolygon _this, int index)
{
    return _this->array[index];
}

void Polygon_addPoint(PPolygon _this, PPoint point)
{
    _this->array =  (PPoint *) realloc(_this->array, (_this->noe+1) * sizeof(PPoint));
    _this->noe = _this->noe + 1;

    _this->array[(_this->noe)] = point;
}

void Polygon_insertPointAt(PPolygon _this, PPoint point, int index)
{
    _this->array =  (PPoint *) realloc(_this->array, (_this->noe+1) * sizeof(PPoint));
    _this->noe = _this->noe + 1;

    int i = _this->noe;

    for(; i>index; i--)
    {
        _this->array[i] = _this->array[i-1];
    }

    _this->array[index] = point;
}

void Polygon_print(PPolygon _this)
{
    printf("Noe = %d", _this->noe);

    for(int i=0; i<(_this->noe); i++)
    {
        Point_print(_this->array[i]);
    }

    printf("\n\n\n------------------------------------------------------------------------------------------------------\n\n");
}

int Polygon_getDataSize(PPolygon _this)
{
    return (sizeof(struct Polygon));
}

int Polygon_isEqual(PPolygon _this, PPolygon polygon){

    for(int i=0;i<_this->noe;i++){
        if(Point_isEqual(_this->array[i],polygon->array[i])){
        }else{
            return 0;
        }
    }
    return 1;
}

int Polygon_isEqualPointList(PPolygon _this, int pl[][2], int noe){

    for(int i=0;i<_this->noe&&i<noe;i++){
        if(Point_isEqualCoord(_this->array[i],pl[i])){
        }else{
            return 0;
        }
    }
    if(_this->noe!=noe){
        return 0;
    }else{
        return 1;
    }
}
void Polygon_delete(PPolygon _this){

    for(int i=0;i<_this->noe;i++){
        Point_delete(_this->array[i]);
    }
    free(_this->array);
    free(_this);
}

