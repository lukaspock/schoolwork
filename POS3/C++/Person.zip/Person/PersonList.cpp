#include "PersonList.h"



CPersonList::CPersonList()
{
    this->pList = nullptr;
    this->noe = 0;
}




void CPersonList::add(CPerson *p){
    CPerson** tempArray = new CPerson*[this->noe + 1];

    for (int i = 0; i < this->noe; ++i) {
        tempArray[i] = this->pList[i];
    }

    tempArray[this->noe] = p;

    delete[] this->pList;
    this->pList = tempArray;
    this->noe += 1;
}

void CPersonList::removeAt(int index)
{
    if( index > this->noe)
    {
        cout << "ERROR: INDEX > NOE" ;
        return;
    }

    CPerson** tempArray = new CPerson*[this->noe - 1];

    for (int i = 0; i < index; ++i)
    {
        tempArray[i] = this->pList[i];
    }

    for (int i = index + 1 ; i < this->noe; ++i)
    {
        tempArray[i] = this->pList[i];
    }

    delete[] this->pList;
    this->pList = tempArray;
    this->noe += 1;
}

void CPersonList::show()
{
    cout << endl << endl << "noe: " <<this->noe << endl << endl ;

    for(int i = 0 ; i < this->noe; i++)
    {
        this->pList[i]->show();
    }
}

CPersonList CPersonList::getPersonListFromWithZIP(const char zipCode) const
{

     CPersonList pL;

    for (int i = 0; i < this->noe; ++i)
    {
        if (this->pList[i]->getZipCodeFromPerson() == zipCode)
        {
            pL.add(this->pList[i]);
        }
    }

    return pL;
}
