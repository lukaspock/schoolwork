
#include "MyUtils.h"
#include <sstream>

using namespace std;

string MyUtils::toString(int iVal){
    ostringstream oss;
    oss << iVal;
    return oss.str();  //returns the content of the stream as string
}
