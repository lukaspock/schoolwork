#include "Person.h"
#pragma once

class CPersonList {

private:
    CPerson **pList;
    int noe;

public:
    CPersonList();
    void add(CPerson *p);
    void removeAt(int index);
    void show();
    CPersonList getPersonListFromWithZIP(const char zipCode) const;
};

