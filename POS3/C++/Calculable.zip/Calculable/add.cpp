#include "add.h"

double Add::calculate(double lVal, double rVal)const
{
    return lVal + rVal;
}

string Add::getOperator()const
{
    return "+";
}
