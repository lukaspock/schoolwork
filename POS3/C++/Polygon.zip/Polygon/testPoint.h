
#include "Point.h"

void testPoint_print(PPoint _this);
void testPoint_getDataSize();
void testPoint_isEqualCoord(PPoint _this, int point[2]);
void testPoint_isEqual(PPoint _this, PPoint point);
void testPoint_delete(PPoint _this);
