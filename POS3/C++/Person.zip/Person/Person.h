#include <string>
#include <iostream>
#pragma once
using namespace std;

class CString {
private:
    const string name;
public:
    CString(string n): name(n) {}
    void show();
};
//CString::CString(string n): name(n) {}

class CAddress {
private:
    const string street;
    const int zipCode;
    const string city;
public:
    CAddress(string s, int z, string c): street(s), zipCode(z), city(c) {}
    void show();
    int getZipCodeFromAddress();
};
//CAddress::CAddress(string s,int z, string c): street(s), zipCode(z), city(c) {}

class CPhonenumber {
private:
    const string phone;
public:
    CPhonenumber(string p): phone(p) {}
    void show();
}; // phone as a string
//CPhonenumber::CPhonenumber(string p): phone(p) {}

class CDate{
private:
    const int day;
    const int month;
    const int year;
public:
    CDate(int d, int m, int y): day(d), month(m), year(y) {}
    void show();
};         // day, month, year as int
//CDate::CDate(int d, int m, int y): day(d), month(m), year(y) {}

class CPerson{
  private:
    CString m_name;
    CAddress m_address;
    CPhonenumber m_telnr;
    CPhonenumber m_faxnr;
    CDate m_birthdate;
  public:
    CPerson(string n, string s, int z, string c, string t, string f, int d, int m, int y): m_name(n), m_address(s,z,c), m_telnr(t), m_faxnr(f), m_birthdate(d,m,y) {}
    //CPerson(): m_name(""), m_address(0,0,""), m_telnr(""), m_faxnr(""), m_birthdate(0,0,0) {}
    void show();
    int getZipCodeFromPerson();

};
//CPerson::CPerson(string n, string s, int z, string c, string t, string f , int d, int m, int y): m_name(n), m_address(s,z,c), m_telnr(t), m_faxnr(f), m_birthdate(d,m,y) {}

