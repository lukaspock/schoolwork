#pragma once
#include "Calculable.h"

class Multiply : public Calculable {

public:
    virtual double calculate(double lVal, double rVal)const;
    virtual string getOperator()const;
};
