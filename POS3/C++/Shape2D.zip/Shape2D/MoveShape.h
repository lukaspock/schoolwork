
#include "menu.h"

class MoveShape : public MenuItem{

private:
    CShape2DList* ptr;

public:
    MoveShape(CShape2DList* p);
    virtual char* getText();
    virtual char getShortCut();
    virtual void execute();
};
