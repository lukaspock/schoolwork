
#include "Teacher.h"

Teacher::Teacher(int d, int m, int y, const string &fN, const string &lN, int sSN, int eN):
    Person(d,m,y,fN,lN,sSN), employeeNum(eN){}

string Teacher::toJSON() const
{
    return Person::toJSON() + ", \"EmployeeNumber\": \"" + MyUtils::toString(this->employeeNum) + "\"" +"";
}

void Teacher::setEmployeeNum(int eN)
{
    this->employeeNum = eN;
}

int Teacher::getEmployeeNum()const
{
    return this->employeeNum;
}
