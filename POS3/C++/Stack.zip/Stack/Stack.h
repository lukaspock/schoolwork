
#pragma once
#include <iostream>

using namespace std;
// stack with fixed array size
const int SIZE=100;

class Stack{
  private:
     int stack[SIZE];
     int si;  //stack index
  public:
     Stack();
     void push (int val);
     int pop ();
     bool isEmpty ();
     bool isFull ();
     void print();
};
