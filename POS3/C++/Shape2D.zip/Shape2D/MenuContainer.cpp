
#include "menu.h"
#include "MenuContainer.h"

MenuContainer::~MenuContainer()
{
    delete[] this->menuList;
}

MenuContainer::MenuContainer()
{
    this->noe = 0;
    this->menuList = nullptr;
}

MenuContainer::MenuContainer(const MenuContainer& orig)
{
    this->noe = orig.noe;

    this->menuList = new MenuItem*[this->noe];

    for(int i = 0; i < this->noe; i++)
    {
        this->menuList[i] = orig.menuList[i];
    }
}

MenuContainer& MenuContainer::operator=(const MenuContainer& orig)
{
    if(this == &orig)
    {
        return *this;
    }

    this->noe = orig.noe;

    delete[] this->menuList;

    this->menuList = new MenuItem*[this->noe];

    for(int i = 0; i < this->noe; i++)
    {
        this->menuList[i] = orig.menuList[i];
    }

    return *this;
}

void MenuContainer::addMenuItem(MenuItem *item)
{
    this->noe++;
    MenuItem** l = new MenuItem*[this->noe];

    for (int i = 0; i < this->noe - 1; i++)
    {
        l[i] = this->menuList[i];
    }

    l[this->noe - 1] = item;

    delete[] this->menuList;
    this->menuList = l;
}

void MenuContainer::showMenus()
{
    for(int i = 0; i < this->noe; i++)
    {
        cout << this->menuList[i]->getText() << endl;
    }
}

void MenuContainer::executeMenuItem(char shortcut)
{
    for(int i=0; i < this->noe; i++)
    {
        if(this->menuList[i]->getShortCut() == shortcut)
        {
            this->menuList[i]->execute();
        }
    }
}



