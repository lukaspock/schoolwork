
#include "Person.h"

Person::Person(int d, int m, int y, const string& fN, const string& lN, int sSN):
    Date(d,m,y), firstName(fN), lastName(lN), socSecNum(sSN){}


string Person::toJSON() const
{
    return Date::toJSON() + "\"firstName\": \"" + this->firstName + "\"" +
           ", \"lastName\": \"" + this->lastName + "\"" +
           ", \"socSecNum\": " + MyUtils::toString(this->socSecNum);
}

string Person::getFirstName() const
{
    return this->firstName;
}

string Person::getLastName() const
{
    return this->lastName;
}

int Person::getSocSecNum() const
{
    return this->socSecNum;
}

void Person::setFirstName(const string& fN)
{
    this->firstName = fN;
}

void Person::setLastName(const string& lN)
{
    this->lastName = lN;
}

int Person::setsocSecNum(int sSN)
{
    this->socSecNum = sSN;
}
