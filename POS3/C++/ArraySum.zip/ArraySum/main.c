#include <stdio.h>
#include <stdlib.h>

double sumUpArray(double doubleVek[], int noe);
double testsumUpArray(double Array[], int noe);

int main()
{
    double testVektor[5] = {1,2,3,4,5};
    testsumUpArray(testVektor, 5);
    return 0;
}

double sumUpArray(double doubleVek[], int noe)
{
    double erg = 0;

    for(int i=0; i<noe; i++)
    {
        erg = erg+doubleVek[i];
    }

    return erg;
}

double testsumUpArray(double Array[] ,int noe)
{
    double erg = sumUpArray(Array, noe);

    printf("RV von sumUpArray %lf", erg);
}
