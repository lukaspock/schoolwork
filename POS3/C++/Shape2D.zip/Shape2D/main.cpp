#include <iostream>
#include "CShape2D.h"
#include "CPoint2D.h"
#include "CCircle.h"
#include "CRectangle.h"
#include "Menu.h"
#include "MenuContainer.h"


using namespace std;

int main()
{
    MenuContainer m;
    CShape2DList* shapeList = new CShape2DList();
    AddCircle* aC = new AddCircle(shapeList);
    AddRectangle* aR = new AddRectangle(shapeList);
    ShowShapes* sS = new ShowShapes(shapeList);
    ScaleShapes* sS2 = new ScaleShapes(shapeList);
    MoveShape* mS = new MoveShape(shapeList);
    TotalAreaShape* tA = new TotalAreaShape(shapeList);
    getQuadrantShape* gQS = new getQuadrantShape(shapeList);
    ShapesInQuadrant* sIQ = new ShapesInQuadrant(shapeList);

    m.addMenuItem(aC);
    m.addMenuItem(aR);
    m.addMenuItem(sS);
    m.addMenuItem(sS2);
    m.addMenuItem(mS);
    m.addMenuItem(tA);
    m.addMenuItem(gQS);
    m.addMenuItem(sIQ);

    char question;
    int question2;

    do{
        system("cls");
        cout << "What do you want to do?" << endl;
        m.showMenus();
        cin >> question;
        m.executeMenuItem(question);

        cout << endl << endl << "Do you want to continue? (0/1)" << endl;
        cin >> question2;
    }while(question2 == 1);

}
