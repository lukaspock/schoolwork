
#include "menu.h"

class ShowShapes : public MenuItem{

private:
    CShape2DList* ptr;

public:
    ShowShapes(CShape2DList* p);
    virtual char* getText();
    virtual char getShortCut();
    virtual void execute();
};
