#include "subtract.h"

double Subtract::calculate(double lVal, double rVal)const
{
    return lVal - rVal;
}

string Subtract::getOperator()const
{
    return "-";
}
