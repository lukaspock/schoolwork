#include "Instrument.h"

Instrument::Instrument(string n, int noM, string* majorList)
{
    this->name = n;
    this->numberOfMajor = noM;

    this->majorList = new string[noM];

    for(int i=0; i < this->numberOfMajor; i++)
    {
        this->majorList[i] = majorList[i];
    }
}

Instrument::~Instrument()
{
    delete[] this->majorList;
}

Instrument::Instrument(const Instrument& other)
{
    this->name = other.name;
    this->numberOfMajor = other.numberOfMajor;
    this->majorList = new string[other.numberOfMajor];

    for(int i=0; i < this->numberOfMajor; i++)
    {
        this->majorList[i] = other.majorList[i];
    }
}

Instrument& Instrument::operator=(const Instrument& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator

    delete[] this->majorList;

    this->name = rhs.name;

    this->majorList = new string[rhs.numberOfMajor];
    this->numberOfMajor = rhs.numberOfMajor;


    for(int i=0; i < this->numberOfMajor; i++)
    {
        this->majorList[i] = rhs.majorList[i];
    }

    return *this;
}

void Instrument::print()
{
    cout << endl << "Name: " << this->name;
    cout << endl << "NOM:  " << this->numberOfMajor;

    for(int i=0 ; i < this->numberOfMajor; i++)
    {
        cout << endl << "List: " << this->majorList[i];
    }
}

void Instrument::setMajorList(string* mL, int nOM)
{
    delete[] this->majorList;

    this->numberOfMajor = nOM;
    this->majorList = new string[nOM];

    for(int i=0; i < nOM ; i++)
    {
        this->majorList[i] = mL[i];
    }
}
