
#include <iostream>

using namespace std;

const int STACKSIZE = 100;

class Stack{

private:
    int si;
    int size;
    double *stack;

public:
    Stack(int size);
    Stack();
    ~Stack();
    Stack(const Stack &s);
    int getEleCnt();
    bool isFull();
    bool isEmpty();
    void push(double val);
    double pop();
    double peek();
    void show();
    int getSize();
    bool chgSize(int newSize);
};
