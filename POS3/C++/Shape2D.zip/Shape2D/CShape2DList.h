#pragma once

#include "CShape2D.h"
#include "CCircle.h"
#include "CRectangle.h"

using namespace std;

class CShape2DList {

    private:
        CShape2D** list;
        int noe;

    public:
        CShape2DList();
        virtual ~CShape2DList();
        CShape2DList(const CShape2DList& orig);
        CShape2DList& operator=(const CShape2DList orig);

        void addShape(CShape2D* s);

        void show(int idx);
        CShape2D** getList(){return this->list;};
        int getNoe(){return this->noe;};
};
