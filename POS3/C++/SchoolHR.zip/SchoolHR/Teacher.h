
#pragma once
#include <string>
#include "Person.h"

using namespace std;

class Teacher: public Person{

protected:
    int employeeNum;

public:
    Teacher(int d, int m, int y, const string& fN, const string &lN, int sSN, int eN);
    string toJSON() const;
    void setEmployeeNum(int eN);
    int getEmployeeNum()const;

};
