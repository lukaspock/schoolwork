#include <iostream>
#include "Product.h"
using namespace std;
Product* read();
void sort(Product *pList, int noe);
void printTable(Product *pList[], int noe);


int main()
{
    cout << "Hello world!" << endl;

    Product* p1 = read();
    p1->show();
    Product* p2 = read();
    p2->show();
    Product* p3 = read();
    p3->show();

    Product *pList[3];

    pList[0] = p1;
    pList[1] = p2;
    pList[2] = p3;

    cout << endl << endl;

    for(int i=0; i<3; i++)
    {
        cout << i+1<< "." << endl;
        pList[i]->show();
    }

    sort(*pList, 3);



    printTable(pList, 3);


    return 0;
}

Product* read()
{
    int id;
    char name[30];
    double price;
    int shelf;

    cout << endl << "Eingabe id: ";
    cin >> id;

    cout << endl << "Eingabe Name: ";
    cin >> name;

    cout << endl << "Eingabe price: ";
    cin >> price;

    cout << endl << "Eingabe shelf: ";
    cin >> shelf;

    Product* p = new Product(id,name,price,shelf);
    return p;
}

void sort(Product *pList, int noe){     // funktioniert nicht

    for (int i = 0; i < noe - 1; i++) {

        bool swapped = false;

        for (int j = 0; j < noe - i - 1; j++)
        {

                if(pList[j].getId() > pList[j+1].getId())
                    {
                    swap((pList[j]), (pList[j + 1]));
                    swapped = true;

                    }
        }

        if(!swapped)
        {
            break;
        }
    }
}

void printTable(Product *pList[], int noe)
{
    cout << endl << "ID:" << "\t" << "NAME:" << "\t" << "PRICE" << "\t" << "SHELF:" << endl;
    for(int i=0; i<noe; i++)
    {
        cout << pList[i]->getId() << "\t" << pList[i]->getName() << "\t" << pList[i]->getPrice() << "\t" << pList[i]->getShelf() << endl;
    }
}
