#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include "person.h"
using namespace std;




void print(char * str) {
    puts(str);
}

void print(const int x[], const int num,  const char * const separator = " ")
{
    if(separator == ", ")
    {
        for(int i = 0; i < num; i++) {
        if(i > 0)
        {
            cout << separator;
        }
        else{
            cout << "";
        }
        cout << x[i];
        }
    }
    else if(separator == " ")
    {
        for(int i = 0; i < num; i++) {
        cout << x[i];
        }
    }

}

void print( double const & d) {
    cout << d;
}

int main() {

//Iteration 1

  const int x[] = {1,2,3};

  print(x, 3);

  cout << "\n";
  print("And now with separator: ");
  print(x, 3, ", ");

  cout << "\n" << "\n";
  const double d = 2.34;
  print(d);
  cout << "\nUnchanged value:" << d;

  int *y = new int[3];
  y[0] = 10;
  y[1] = 20;
  y[2] = 30;
  cout << "\n";
  print(y, 3);
  delete[] y;




//Iteration 2

  cout << endl << endl;

  Person p;
  initPerson(p, 1, "Christoph");
  printPerson(p);


  Person* ppointer = new Person;
  initPerson(*ppointer, 2, "Gregor");
  printPerson(*ppointer);
  delete ppointer;

  Person* parray = new Person[3];
  initPerson(parray[0], 1, "Jakob");
  initPerson(parray[1], 2, "Julian");
  initPerson(parray[2], 3, "Justin");
  printPerson(parray, 3);
  delete parray;

}

