#include "StringedInstrument.h"

StringedInstrument::StringedInstrument(string n, int noM, string* majorList, int nOS, char* sL): Instrument(n,noM,majorList), numberOfStrings(nOS)
{
    this->stringList = new char[nOS];

    for(int i=0; i < nOS ;  i++)
    {
        this->stringList[i] = sL[i];
    }
}

StringedInstrument::~StringedInstrument()
{
    delete[] this->stringList;
}

StringedInstrument::StringedInstrument(const StringedInstrument& other)
: Instrument(other.name, other.numberOfMajor, other.majorList)
{
    this->copy(other);
}

StringedInstrument& StringedInstrument::operator=(const StringedInstrument& rhs)
{
    if (this == &rhs) return *this; // handle self assignment

    Instrument::operator=(rhs);
    delete[] this->stringList;
    this->copy(rhs);

    return *this;
}

void StringedInstrument::copy(const StringedInstrument& other)
{
    this->numberOfStrings = other.numberOfStrings;

    this->stringList = new char[this->numberOfStrings];

    for(int i=0; i < this->numberOfStrings ; i++)
    {
        this->stringList[i] = other.stringList[i];
    }
}

void StringedInstrument::setStringList(char* sL, int nOS)
{
    delete[] this->stringList;

    this->numberOfStrings = nOS;
    this->stringList = new char[nOS];

    for(int i=0; i < nOS ; i++)
    {
        this->stringList[i] = sL[i];
    }
}

void StringedInstrument::print()
{
    Instrument::print();

    cout << endl << "Number Of Strings: " << this->numberOfStrings;

    for(int i = 0; i < this->numberOfStrings; i++)
    {
        cout << endl << "String List[" << i + 1 << "]: " << this->stringList[i];
    }

}

void StringedInstrument::setName(string n)
{
    this->name = n;
}
