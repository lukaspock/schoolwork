#ifndef FRACTION_H
#define FRACTION_H

#include <iostream>

using namespace std;

class Fraction
{
    public:
         Fraction(int=0,int=1);
         friend Fraction operator*(const Fraction &a, const Fraction &b);
         friend int operator==(const Fraction &a, const Fraction &b);
         friend Fraction operator~(const Fraction &a);
         friend Fraction& operator++( Fraction &a); // prefix
         friend Fraction operator++(Fraction &a, int);   // postfix
         friend Fraction operator+(const Fraction &a, const Fraction &b);
         friend Fraction operator-(const Fraction &a, const Fraction &b);
         friend Fraction operator/(const Fraction &a, const Fraction &b);
         friend int operator<(const Fraction &a, const Fraction &b);
         friend int operator>(const Fraction &a, const Fraction &b);
         friend int operator<=(const Fraction &a, const Fraction &b);
         friend int operator>=(const Fraction &a, const Fraction &b);
         friend int operator!=(const Fraction &a, const Fraction &b);
         Fraction& operator--(); // prefix
         Fraction operator--(int); // postfix
         void show();
    private:
        int numerator;
        int denominator;
};

#endif // FRACTION_H
