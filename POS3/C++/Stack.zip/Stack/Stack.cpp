#include "Stack.h"

Stack::Stack(){
   this->si = -1; // or 0
}

void Stack::push (int val)
{
    this->si = this->si + 1;
    this->stack[this->si] = val;
}

int Stack::pop ()
{
    if(this->isEmpty())
    {
        cout << "ERROR INDEX -1" << endl;
    }
    this->si = this->si - 1;

    return this->stack[this->si+1];
}

bool Stack::isEmpty ()
{
    if(this->si == -1)
    {
        return 1;
    }

    return 0;

}

bool Stack::isFull ()
{
    if(this->si >= SIZE-1)
    {
        return 1;
    }

    return 0;
}

void Stack::print()
{

    if(this->isEmpty())
    {
        cout << "Error Stack is empty" << endl;
        return;
    }
    cout << endl << endl << "Ausgabe Stack:" << endl << endl;

    for(int i=0; i<=this->si; i++)
    {
        cout << this->stack[i] << ", ";
    }
    cout << endl;
}
