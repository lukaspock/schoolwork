
#include "ProductList.h"

ProductList::ProductList()
{
    this->pList = nullptr;
    this->noe = 0;
}


void ProductList::add(Product* p)
{
    Product** temp = new Product*[this->noe+1];

    this->noe = this->noe + 1;

    for(int i=0; i< this->noe - 1; i++)
    {
        temp[i] = this->pList[i];
    }

    temp[this->noe] =  p;

    this->pList = temp;

}

void ProductList::remove(int index)
{
    ;
}

Product* ProductList::getAt(int index)
{
    ;
}

void ProductList::sortById()
{
    ;
}
