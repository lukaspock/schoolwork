#include "CShape2D.h"

CShape2D::CShape2D(int r,int g,int b, int l, bool iF):color(r,g,b), line(l), isFilled(iF)
    {
        if(l != 1 && l != 2  && l != 3)
        {
            cout << endl << endl << "invalid line, only 1/2/3 allowed" << endl << endl;
            this->line = 0;
        }
    }

