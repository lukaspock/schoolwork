#include <iostream>
#include "Student.h"
#include "Employee.h"
using namespace std;


double averageAge(Student* s, int noe)
{
    double result = 0;

    for(int i = 0; i < noe; i++)
    {
        result += s[i].getAge(2025);
    }

    return result / noe;
}

double averageAge(Employee* e, int noe)
{
    double result = 0;

    for(int i = 0; i < noe; i++)
    {
        result += e[i].getAge(2025);
    }

    return result / noe;
}

int main()
{
    Student s1("Jakob", "3BHIF", 2008);     //16
    Student s2("Balogh", "3BHIF", 2020);    //4
    Student s3("Vortschi", "3BHIF", 2007);  //17
    Student s4("Lukas", "3BHIF", 2008);     //16
    Student s5("Justin", "3BHIF", 2010);    //14

    Student ar[5];

    ar[0] = s1;
    ar[1] = s2;
    ar[2] = s3;
    ar[3] = s4;
    ar[4] = s5;

    Employee e1("Anna", 2500, 2009);        //15
    Employee e2("Samara", 2000, 2009);      //15
    Employee e3("Lars", 1000, 2008);        //16
    Employee e4("Marian", 2000, 2007);      //17
    Employee e5("Laura", 3000, 2007);       //17

    Employee ar2[5];

    ar2[0] = e1;
    ar2[1] = e2;
    ar2[2] = e3;
    ar2[3] = e4;
    ar2[4] = e5;

    cout << endl << endl << "Ausgabe Students" << endl;
    for(int i = 0; i < 5; i++)
    {
        ar[i].show();
    }

    cout << endl << endl << "Ausgabe Employees" << endl;
    for(int i = 0; i < 5; i++)
    {
        ar2[i].show();
    }

    double result = averageAge(ar, 5);
    double result2 = averageAge(ar2, 5);

    cout << endl << endl << "Average age Students: " << result;
    cout << endl << endl << "Average age Employees: " << result2;

    return 0;
}
