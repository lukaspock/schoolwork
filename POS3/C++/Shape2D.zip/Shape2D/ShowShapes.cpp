#include "MenuContainer.h"


ShowShapes::ShowShapes(CShape2DList* p)
{
    this->ptr = p;
}

char* ShowShapes::getText()
{
    return "3. Show all Shapes";
}

char ShowShapes::getShortCut()
{
    return '3';
}

void ShowShapes::execute()
{
    system("cls");
    for(int i = 0; i < this->ptr->getNoe(); i++)
    {
        cout << i+1 << ". Shape: " << endl << endl;
        this->ptr->show(i);
    }
}
