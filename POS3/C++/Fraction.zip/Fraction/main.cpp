#include <iostream>
#include "Fraction.h"
#include "testFraction.h"

using namespace std;

int main() {
    testOperatorMultiply(2, 3, 4, 5);
    testOperatorEqual(2, 3, 4, 6);
    testOperatorReciprocal(3, 4);
    testOperatorPrefixIncrement(1, 2);
    testOperatorPostfixIncrement(1, 2);
    testOperatorAdd(1, 3, 2, 5);
    testOperatorSubtract(3, 4, 1, 6);
    testOperatorDivide(1, 3, 2, 5);
    testOperatorLessThan(1, 2, 3, 4);
    testOperatorGreaterThan(3, 4, 1, 2);
    testOperatorLessThanOrEqual(3, 4, 3, 4);
    testOperatorGreaterThanOrEqual(3, 4, 1, 2);
    testOperatorNotEqual(2, 3, 3, 4);
    testOperatorPrefixDecrement(5, 6);
    testOperatorPostfixDecrement(5, 6);

    return 0;
}
