#ifndef INSTRUMENT_H
#define INSTRUMENT_H
#include "String.h"
#include "iostream"

using namespace std;


class Instrument
{
    public:
        Instrument(string n = "", int noM = 0, string* majorList = nullptr);
        ~Instrument();
        Instrument(const Instrument& other);
        Instrument& operator=(const Instrument& other);

        string getName() { return name; }
        void setname(string val) { name = val; }
        int getnumberOfMajor() { return numberOfMajor; }
        string* getMajorList() { return majorList; }
        void setMajorList(string* mL, int nOM);
        void print();

    protected:
        string name;
        int numberOfMajor;
        string* majorList;
};

#endif // INSTRUMENT_H
