#include "CCircle.h"

CCircle::CCircle(int r,int g,int b, int l, bool iF, int x, int y, float rad)
:CShape2D(r,g,b,l,iF), point(x,y), radius(rad){}


string CCircle::toString()
{

    string str = this->color.toString();
    str += "\nLine: " + to_string(this->line) + "\nIsFilled: " + to_string(this->isFilled);
    str += this->point.toString();
    str += "\nRadius: " + to_string(this->radius) + "\n\n";
    return str;
}

ostream& operator<<(ostream& os, CCircle& circle) {
        return os << circle.toString();
    }

void CCircle::scale(int factor)
{
    this->radius = this->radius * factor;
}

void CCircle::move(int xV, int yV)
{
    this->point.setX(this->point.getX() + xV);
    this->point.setY(this->point.getY() + yV);
}

float CCircle::calcShape()
{
    return (this->radius * this->radius * 3.1415);
}

int CCircle::getQuadrant()
{
    return this->point.getQuadrant();
}
