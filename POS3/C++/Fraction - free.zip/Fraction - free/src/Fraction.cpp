#include "Fraction.h"
#include <cmath>

int berechneGGT(int a, int b);
int berechneKGV(int a, int b);

Fraction::Fraction(int num, int denom) : numerator(num), denominator(denom) {
    if (denominator < 0) {
        numerator = -num;
        denominator = -denom;
    }
}

Fraction operator*(const Fraction &a, const Fraction &b) {
    return Fraction(a.numerator * b.numerator, a.denominator * b.denominator);
}

int operator==(const Fraction &a, const Fraction &b) {
    return (a.numerator * b.denominator == b.numerator * a.denominator);
}

Fraction operator~(const Fraction &a) {
    return Fraction(a.denominator, a.numerator);
}

Fraction& operator++(Fraction &a) {
    a.numerator += a.denominator;
    return a;
}

Fraction operator++(Fraction &a, int) {
    Fraction temp = a;
    a.numerator += a.denominator;
    return temp;
}

Fraction operator+(const Fraction &a, const Fraction &b) {
    int lcm = berechneKGV(a.denominator, b.denominator);
    int num = (lcm / a.denominator) * a.numerator + (lcm / b.denominator) * b.numerator;
    return Fraction(num, lcm);
}

Fraction operator-(const Fraction &a, const Fraction &b) {
    int lcm = berechneKGV(a.denominator, b.denominator);
    int num = (lcm / a.denominator) * a.numerator - (lcm / b.denominator) * b.numerator;
    return Fraction(num, lcm);
}

Fraction operator/(const Fraction &a, const Fraction &b) {
    return Fraction(a.numerator * b.denominator, a.denominator * b.numerator);
}

int operator<(const Fraction &a, const Fraction &b) {
    return a.numerator * b.denominator < b.numerator * a.denominator;
}

int operator>(const Fraction &a, const Fraction &b) {
    return a.numerator * b.denominator > b.numerator * a.denominator;
}

int operator<=(const Fraction &a, const Fraction &b) {
    return !(a > b);
}

int operator>=(const Fraction &a, const Fraction &b) {
    return !(a < b);
}

int operator!=(const Fraction &a, const Fraction &b) {
    return !(a == b);
}

Fraction& Fraction::operator--() {
    numerator -= denominator;
    return *this;
}

Fraction Fraction::operator--(int) {
    Fraction temp = *this;
    numerator -= denominator;
    return temp;
}

void Fraction::show() {
    cout << numerator << "/" << denominator << endl;
}

int berechneGGT(int a, int b) {
    while (b != 0) {
        int rest = a % b;
        a = b;
        b = rest;
    }
    return abs(a);
}

int berechneKGV(int a, int b) {
    return abs(a * b) / berechneGGT(a, b);
}
