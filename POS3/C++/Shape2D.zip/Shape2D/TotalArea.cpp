#pragma once
#include "MenuContainer.h"


TotalAreaShape::TotalAreaShape(CShape2DList* p)
{
    this->ptr = p;
}

char* TotalAreaShape::getText()
{
    return "6. Calc Total Area";
}

char TotalAreaShape::getShortCut()
{
    return '6';
}

void TotalAreaShape::execute()
{

    system("cls");

    float tA = 0;

    for(int i = 0; i < this->ptr->getNoe(); i++)
    {
        tA += this->ptr->getList()[i]->calcShape();
    }

    cout << "Total Area: " << tA;

}

