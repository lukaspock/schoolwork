#pragma once
#include "Calculable.h"

class Divide : public Calculable{

public:
    virtual double calculate(double lVal, double rVal)const;
    virtual string getOperator()const;
};
