
#include "DynamicStack.h"

//Constructor Mit gegebener size als Parameter
Stack::Stack(int size)
{
    if(size > STACKSIZE)
    {
        cout << "Error" << endl << "size > Stacksize" << endl;
        return;
    }
        this->si = -1;
        this->size = size;
        this->stack = new double[size];
}

// Constructor Ohne Parameter (Default = STACKSIZE)
Stack::Stack()
{
        this->si = -1;
        this->size = STACKSIZE;
        this->stack = new double[STACKSIZE];
}

Stack::~Stack()
{
        delete[] this->stack;
}

Stack::Stack(const Stack &s)
{
    this->si = s.si;
    this->size = s.size;

    this->stack = new double[this->size];

    for(int i=0; i<=this->si ; i++)
    {
        this->stack[i] = s.stack[i];
    }
}


int Stack::getEleCnt()
{
    return (this->si)+1;
}

bool Stack::isFull()
{
    if(this->si+1 >= this->size)
    {
        return 1;
    }
    else
        return 0;
}

bool Stack::isEmpty()
{
    if(this->si == -1)
    {
        return 1;
    }
    else
        return 0;
}

 void Stack::push(double val)
 {
    if(isFull())
     {
         cout << "ERROR with push: Stack Is Full" << endl;
         return;
     }
    else
    {
        this->si = this->si + 1;
        int help = this->si;
        this->stack[help] = val;
    }


 }

double Stack::pop()
{
    this->si = this->si - 1;
    return this->stack[(this->si)+1];
}

double Stack::peek()
{
    return this->stack[(this->si)];
}

void Stack::show()
{
    cout << endl;
    cout << "Stack Index: " << endl << this->si << endl;
    cout << "Max Stack Size: " << endl << this->size << endl;
    cout << "Ausgabe Stack: " << endl ;

    for(int i=0; i <= this->si ; i++)
    {
        cout << i+1 << ". Element: " << this->stack[i] << endl;
    }
}

int Stack::getSize()
{
    return this->size;
}

bool Stack::chgSize(int newSize)
{
    if(newSize < this->size)
    {
        cout << "New Size ist gr��er als Current size" << endl;
        return 0;
    }

    double *newStack = new double[newSize];

    for(int i=0; i<newSize; i++)
    {
        newStack[i] = this->stack[i];
    }

    this->stack = newStack;
    this->size = newSize;

    return 1;
}
