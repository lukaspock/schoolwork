#include "menu.h"
class AddRectangle :  public MenuItem{

private:
    CShape2DList* ptr;

public:
    AddRectangle(CShape2DList* p);
    virtual char* getText();
    virtual char getShortCut();
    virtual void execute();
};
