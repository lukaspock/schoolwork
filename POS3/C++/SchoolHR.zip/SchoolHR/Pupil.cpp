

#include "Pupil.h"
#include "MyUtils.h"

Pupil::Pupil(int d, int m, int y, const string& cN, const string& fN, const string& lN, int sSN) :
    Person(d, m , y,fN,lN,sSN), className(cN) {}

string Pupil::getClassName() const {
    return this->className;
}

void Pupil::setClassName(const string& cN) {
    this->className = cN;
}

string Pupil::toJSON() const {
    return Person::toJSON() + ", \"className\": \"" + this->className + "\"" +"";
}
