#include <stdio.h>
#include <stdlib.h>
#include "Point.h"
#include "testPoint.h"
#include "Polygon.h"
#include "testPolygon.h"
#include "PolygonDAO.h"


int main()
{

    int pl1[3][2] = {{1,2},{3,4},{5,6}};
    int pl2[3][2] = {{7,8},{9,10},{11,12}};
    int pl3[3][2] = {{13,14},{15,16},{17,18}};

    PPolygon polygon1 = Polygon_create (pl1, 3);
    PPolygon polygon2 = Polygon_create (pl2, 3);
    PPolygon polygon3 = Polygon_create (pl3, 3);

     PPolygon expectedPolygonList[] = {polygon1, polygon2, polygon3};

    PPolygon polygonList[3];
    polygonList[0] = polygon1;
    polygonList[1] = polygon2;
    polygonList[2] = polygon3;

    int newPoints[][2] = {{9, 9}, {10, 10}, {11, 11}};
    PPolygon newPolygon = Polygon_create(newPoints, 3);
    expectedPolygonList[1] = newPolygon;


    Polygon_print(polygon1);


    // ADT PolygonDAO

    PPolygonDAO  polygonDAO = PolygonDAO_create("Polygon.dat");
    //PolygonDAO_writePolygon( polygonDAO, polygon1);

    PolygonDAO_writePolygonList(polygonDAO, polygonList, 3);

    PPolygon vortschi = PolygonDAO_readFirstPolygon( polygon1);
    PPolygon jannik = PolygonDAO_readPolygonAt( polygon2,  2);
    PPolygon* balogh = PolygonDAO_readAll( polygon1,  &(Polygon_getNoe));
    PolygonDAO_updatePolygonAt( polygon3,  1,  newPolygon);

    PolygonDAO_delete(polygon1);
    return 0;
}

