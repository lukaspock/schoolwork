#pragma once
#include <iostream>
#include "string.h"
using namespace std;

enum Quadrant {
    Q0 = 0,
    Q1 = 1,
    Q2 = 2,
    Q3 = 3,
    Q4 = 4
    };

class CPoint2D {

private:
    float x;
    float y;


public:
    CPoint2D(float x, float y): x(x), y(y) {};
    string toString();
    friend ostream& operator<<(ostream& o, CPoint2D p);
    void setX(int x) {this->x = x;}
    void setY(int y) {this->y = y;}
    float getX() {return this->x;}
    float getY() {return this->y;}



    int getQuadrant();
};


