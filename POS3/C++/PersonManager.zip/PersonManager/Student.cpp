#include "Student.h"

Student::Student(string n, string f, int b)
{
    this->name = n;
    this->form = f;
    this->birthyear = b;
}

Student::Student(const Student &s)
{
    this->name = s.name;
    this->form = s.form;
    this->birthyear = s.birthyear;
}

void Student::setName(const string n)
{
    this->name = n;
}
void Student::setForm(const string f)
{
    this->form = f;
}
void Student::setBirthyear(const int b)
{
    this->birthyear = b;
}
string Student::getName()
{
    return this->name;
}
string Student::getForm()
{
    return this->form;
}
int Student::getBirthyear()
{
    return this->birthyear;
}
int Student::getAge(int currentYear)
{
    return currentYear - this->birthyear;
}
void Student::show()
{
    cout << endl << endl << "Name: " << this->name;
    cout << endl << "Form: " << this->form;
    cout << endl << "Birthyear: " << this->birthyear;
}


