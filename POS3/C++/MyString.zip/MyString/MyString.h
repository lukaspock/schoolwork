#pragma once
#include <iostream>
#include "string.h"

using namespace std;

class MyString{

    private:
        char *str;
    public:
        MyString(const char *cStr="");
        MyString(const MyString &s);
        ~MyString();
        int getLength()const;
        void show();
        void append(const MyString &str);
        void addChar(char ch);
        char getCharAt(int idx);
        int compare(const MyString &str);
        void toUpper();
        void toLower();
        void insertCharAt(char ch, int idx);
        void insertStrAt(const MyString &str, int idx);
        MyString operator+(const MyString &str);
        MyString operator=(const MyString &s);
        MyString operator++();
        MyString operator++(int dummy);
        MyString operator/(int index);
};
