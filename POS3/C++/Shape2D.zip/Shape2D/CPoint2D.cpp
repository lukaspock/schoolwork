#include "CPoint2D.h"

string CPoint2D::toString()
{
    return "\nX: " + std::to_string(this->x) + "\nY: " + std::to_string(this->y);
}

ostream& operator<<(ostream& o, CPoint2D p)
{
    o << endl << "X: " << p.x << endl << "Y: " << p.y;
}

int CPoint2D::getQuadrant()
{
    if(this->x == 0 || this->y == 0)
        return Quadrant::Q0;

    if(this->x > 0 && this->y > 0)
        return Quadrant::Q1;

    if(this->x < 0 && this->y > 0)
        return Quadrant::Q2;

    if(this->x < 0 && this->y < 0)
        return Quadrant::Q3;

    if(this->x > 0 && this->y < 0)
        return Quadrant::Q0;
}
