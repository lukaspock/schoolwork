#include "Product.h"

class ProductList{

    private:
        Product *pList;
        int noe;

    public:
        ProductList();
        void add(Product* p);
        void remove(int index);
        Product* getAt(int index);
        void sortById();
};
