#include <iostream>
#include "DynamicStack.h"

using namespace std;

int main()
{
    // Stack mit maximaler size von 5
    Stack d(5);

    // 5 doubles werden in den stack gepusht
    d.push(1.1);
    d.push(1.2);
    d.push(1.3);
    d.push(1.4);
    d.push(1.5);

    // Ausgabe Stack mit 5 Elementen
    d.show();

    // getSize
    cout << endl << "Size: " << d.getSize() << endl;

    // getEleCnt
    cout << "Element Count: " << d.getEleCnt() << endl;

    // peek
    cout << "Oberstes Element: " << d.peek() << endl;

    // pop + Ausgabe vom Stack nach pop
    cout << "Oberstes Element: " << d.pop() << endl ;
    d.show();


    // chgSize auf 10 + Ausgabe Stack mit 10 Elementen
    d.chgSize(10);

    d.push(1.5);
    d.push(1.6);
    d.push(1.7);
    d.push(1.8);
    d.push(1.9);
    d.push(1.10);

    d.show();

    // test Copy Constructer + Ausgabe der Kopie
    Stack testcopy(d);
    cout << endl << endl << "Ausgabe copy: " << endl;
    testcopy.show();
}
