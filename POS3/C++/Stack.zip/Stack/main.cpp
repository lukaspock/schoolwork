#include <iostream>
#include "Stack.h"
#include "testStack.h"

using namespace std;

int main()
{
    Stack s;
    int help1;
    int elements[10] = {0,1,2,3,4,5,6,7,8,9};
    int *elements2;
    int j = 0;

    for(int i=0; i<= 100; i++)
    {
        j = j+1;
        elements2[i] = j;

    }

    testStackPush(elements, 10);
    testStackIsEmpty(elements, 10, 3, 0); //should not be empty
    testStackIsFull (elements2, 100, 0, 1);

    return 0;
}
