#include <iostream>
#include "MyString.h"

using namespace std;

int main()
{

    MyString s1("Samuel");
    int length = s1.getLength();
    cout << endl <<"length: " << length << endl << "s1: " ;
    s1.show();

    MyString s10 = ++s1;
    s10.show();


    MyString s20 = s1++;
    s20.show();

    s1.show();

    MyString s30;
    s30 = s1 / 2;
    cout << endl << "s30:" << endl;
    s30.show();

    cout << endl << "s1:" << endl;
    s1.show();

    /*
    cout << endl;

    MyString s2(" Koppel");
    int length2 = s2.getLength();
    cout << endl <<"length: " << length2 << endl << "s2: " ;
    s2.show();

    MyString s3(" Sofie");
    s3.show();

    s3 = s1 + s2;
    s3.show();
    */


/*

    MyString s3(" Sofie");
    int length3 = s3.getLength();
    cout << endl <<"length: " << length3<< endl << "s3: " ;
    s3.show();

    s1.append(s2);
    cout << endl << endl << "s1 + s2: ";
    s1.show();

    char ch = 'e';
    s1.addChar(ch);
    cout << endl << endl << "nach add char: ";
    s1.show();

    int test = s1.compare(s2);
    cout << endl << endl << "Return von compare: " << test;

    char c = s1.getCharAt(3);
    cout << endl << endl << "Char At Index 4: " << c;

    cout << endl << endl;

    s1.toUpper();
    cout << endl << "String nach toUpper(): ";
    s1.show();


    s1.toLower();
    cout << endl << endl << "String nach toLower(): ";
    s1.show();


    s1.insertCharAt('e',2);
    cout << endl << endl << "String nach insert Char At(): ";
    s1.show();

    s1.insertStrAt(s3,6);
    cout << endl << endl << "String nach insert Str At(): ";
    s1.show();
    */
    return 0;
}
