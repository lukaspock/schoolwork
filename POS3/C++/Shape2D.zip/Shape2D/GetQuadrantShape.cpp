
#include "MenuContainer.h"


getQuadrantShape::getQuadrantShape(CShape2DList* p)
{
    this->ptr = p;
}

char* getQuadrantShape::getText()
{
    return "7. Get Quadrant";
}

char getQuadrantShape::getShortCut()
{
    return '7';
}

void getQuadrantShape::execute()
{

    system("cls");

    int idx;
    cout << endl << endl << "What Shape do you want the Qaudrant of?" << endl;
    cin >> idx;
    idx--;
    cout << "Quadrant: " << this->ptr->getList()[idx]->getQuadrant();

}


