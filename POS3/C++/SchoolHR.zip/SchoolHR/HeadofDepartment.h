
#pragma once
#include <string>
#include "Teacher.h"

using namespace std;

class HeadOfDepartment: public Teacher{

protected:
    string departmentName;
public:
    HeadOfDepartment(int d, int m, int y, const string& fN, const string &lN, int sSN, int eN, string dN);
    string toJSON() const;
    void setDepartmentName(const string& s);
    string getDepartmentName()const;
};
