#include "Product.h"
#include <string.h>

Product::Product(int id, char* name, double price, int shelf)
{
    this->id = id;
    strcpy(this->name, name);
    this->price = price;
    this->shelf = shelf;
}

int Product::getId()const
{
    return this->id;
}

void Product::setId(const int id)
{
    this->id = id;
}

char* Product::getName()
{
    return this->name;
}

double Product::getPrice()
{
    return this->price;
}

void Product::setPrice(const int price)
{
    this->price = price;
}

void Product::setName(const char* name)
{
    strcpy(this->name, name);
}

int Product::getShelf()const
{
    return this->shelf;
}

void Product::setShelf(int shelf)
{
    this->shelf = shelf;
}

void Product::show()
{
    cout << "id: " << this->id << endl;
    cout << "name: " << this->name << endl;
    cout << "price: " << this->price << endl;
    cout << "shelf: " << this->shelf << endl;
}

