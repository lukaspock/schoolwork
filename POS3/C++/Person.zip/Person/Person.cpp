#include "Person.h"

void CString::show(){

    cout << "name: " << this->name << endl;
}

void CAddress::show(){

    cout << "city: " << this->city << endl;
    cout << "street: " << this->street << endl;
    cout << "zipcode: " << this->zipCode << endl << endl;

}

void CPhonenumber::show(){

    cout << "phone: " << this->phone << endl << endl;
}

void CDate::show(){

    cout << "day: " << this->day << endl;
    cout << "month: " << this->month << endl;
    cout << "year: " << this->year << endl << endl;
}

void CPerson::show(){

    this->m_name.show();
    this->m_address.show();
    this->m_telnr.show();
    this->m_faxnr.show();
    this->m_birthdate.show();
}

int CPerson::getZipCodeFromPerson()
{
    return this->m_address.getZipCodeFromAddress();
}

int CAddress::getZipCodeFromAddress()
{
    return this->zipCode;
 }
