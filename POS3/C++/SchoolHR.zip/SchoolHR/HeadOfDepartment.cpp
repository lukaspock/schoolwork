
#include "HeadofDepartment.h"

HeadOfDepartment::HeadOfDepartment(int d, int m, int y, const string& fN, const string &lN, int sSN, int eN, string dN):
    Teacher(d,m,y,fN,lN,sSN,eN), departmentName(dN) {}

string HeadOfDepartment::toJSON() const
{
    return Teacher::toJSON() + " DepartmentName:" + this->departmentName;
}

void HeadOfDepartment::setDepartmentName(const string& s)
{
    this->departmentName = s;
}

string HeadOfDepartment::getDepartmentName()const
{
    return this->departmentName;
}
