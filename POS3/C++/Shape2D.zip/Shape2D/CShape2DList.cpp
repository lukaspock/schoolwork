#include "CShape2DList.h"

CShape2DList::CShape2DList()
{
    this->noe = 0;
    this->list = nullptr;
}

CShape2DList::~CShape2DList()
{
    delete[] this->list;
}

CShape2DList::CShape2DList(const CShape2DList& orig)
{
    this->noe = orig.noe;

    this->list = new CShape2D*[this->noe];

    for(int i = 0; i < this->noe; i++)
    {
        this->list[i] = orig.list[i];
    }

}

CShape2DList& CShape2DList::operator=(const CShape2DList orig)
{
    if(this == &orig)
    {
        return *this;
    }

    this->noe = orig.noe;

    delete[] this->list;

    this->list = new CShape2D*[this->noe];

    for(int i = 0; i < this->noe; i++)
    {
        this->list[i] = orig.list[i];
    }

    return *this;
}

void CShape2DList::addShape(CShape2D* s)
{
    this->noe += 1;

    CShape2D** li = new CShape2D*[this->noe];

    for(int i=0; i < this->noe - 1; i++)
    {
        li[i] = this->list[i];
    }

    delete[] this->list;

    li[this->noe - 1] = s;

    this->list = li;
}



void CShape2DList::show(int idx)
{
    cout << "hello" << endl;
    cout << this->list[idx]->toString();

}
