#ifndef FRACTION_H
#define FRACTION_H

#include <iostream>

using namespace std;


class Fraction
{
    public:
         Fraction(int=0,int=1);
         Fraction operator*(const Fraction &a) const;
         int operator==(const Fraction &a) const;
         Fraction operator~(void) const;
         Fraction& operator++(void); // prefix
         Fraction operator++(int);   // postfix
         Fraction operator+(const Fraction &a)const;
         Fraction operator-(const Fraction &a)const;
         Fraction operator/(const Fraction &a) const;
         int operator<(const Fraction &a) const;
         int operator>(const Fraction &a) const;
         int operator<=(const Fraction &a) const;
         int operator>=(const Fraction &a) const;
         int operator!=(const Fraction &a) const;
         Fraction& operator--(void); // prefix
         Fraction operator--(int);   // postfix
         Fraction shorten();
         void show();
    private:
        int numerator;
        int denominator;
};

#endif // FRACTION_H
