
#include "Point.h"

struct Point
{
    int x;  // x - Coordinate of the point
    int y;  // y - Coordinate of the point

};

PPoint Point_create(int x, int y)
{
    PPoint _this = (PPoint)malloc(sizeof(struct Point));

    _this->x = x;
    _this->y = y;

    return _this;
}

void Point_print(PPoint _this)
{
    printf("\n\nAusgabe Point:\nx:%d\ny:%d", _this->x, _this->y);
}

int Point_getDataSize()
{
    return sizeof(struct Point);
}

int Point_isEqualCoord(PPoint _this, int point[2])
{
    if(_this->x == point[0] && _this->y == point[1])
        return 1;
    else
        return 0;
}

int Point_isEqual(PPoint _this, PPoint point)
{
    if(_this->x == point->x && _this->y == point->y)
        return 1;
    else
        return 0;
}

void Point_delete(PPoint _this)
{
    free(_this);
}
