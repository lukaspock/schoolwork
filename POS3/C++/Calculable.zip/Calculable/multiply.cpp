
#include "multiply.h"

 double Multiply::calculate(double lVal, double rVal)const
 {
     return lVal * rVal;
 }

string Multiply::getOperator()const
{
    return "*";
}
