#pragma once
#include <iostream>

using namespace std;

class Calculable{

public:
    virtual double calculate(double lVal, double rVal)const = 0;
    virtual string getOperator()const = 0;
    virtual ~Calculable(){}
};
