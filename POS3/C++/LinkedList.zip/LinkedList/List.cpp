
#include "List.h"

    List::List()
    {
        this->begin = nullptr;
    }

    List::List(const List& l)
    {
        Node* temp = l.begin;

        while(temp != nullptr)
        {
            this->addBack(temp->getData());

            temp = temp->getNext();
        }
    }

    List::~List()
    {
        Node* temp = this->begin;
        Node* temp2;

        while(temp != nullptr)
        {
            temp2 = temp->getNext();
            delete temp;
            temp = temp2;
        }

        this->begin = nullptr;
    }

    void List::addFront(int data)
    {
        Node* temp = new Node(data);
        temp->setNext(this->begin);

        this->begin = temp;
    }

    void List::addBack(int data)
    {
        Node* temp = new Node(data);
        Node* help = this->begin;

        while( help->getNext() != nullptr)
        {
            help = help->getNext();
        }

        help->setNext(temp);
    }


    Node* List::getBegin()const
    {
        return this->begin;
    }


    bool List::contains(int data)
    {
        Node* temp = this->begin;

        while(temp != nullptr)
        {
            if(temp->getData() == data)
            {
                return 1;
            }
            else
            {
                temp = temp->getNext();
            }
        }

        return 0;
    }


    void List::print()
    {
        Node* temp = this->begin;

        while(temp != nullptr)
        {
            temp->show();
            temp = temp->getNext();
        }

    }



