#pragma once
#include "CRectangle.h"
#include "CCircle.h"
#include "CShape2D.h"
#include <iostream>
using namespace std;


class MenuItem{

public:
    virtual char* getText() = 0;
    virtual char getShortCut() = 0;
    virtual void execute() = 0;
};
