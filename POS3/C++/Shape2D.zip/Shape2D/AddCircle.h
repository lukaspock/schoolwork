
#include "menu.h"

class AddCircle : public MenuItem{

private:
    CShape2DList* ptr;

public:
    AddCircle(CShape2DList* p);
    virtual char* getText();
    virtual char getShortCut();
    virtual void execute();
};
