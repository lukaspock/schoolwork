#include "PolygonDAO.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct PolygonDAO
{

    char* filename;

};

PPolygon PolygonDAO_readPolygonHelp(FILE *fp);
void PolygonDAO_writePolygonHelp(FILE *fp, PPolygon polygon);


PPolygonDAO PolygonDAO_create(char *filename)
{

    PPolygonDAO _this=(PPolygonDAO)malloc(sizeof(struct PolygonDAO));

    if(!_this)
    {
        printf("Error");
        return NULL;
    }

    _this->filename=(char*)malloc(strlen(filename));
    strcpy(_this->filename, filename);

    return  _this;
}

void PolygonDAO_writePolygon(PPolygonDAO _this, PPolygon polygon)
{

    FILE * fp = fopen(_this->filename,"ab");

    if (!fp)
    {
        printf("Error");
        return;
    }

    PolygonDAO_writePolygonHelp(fp, polygon);
    fclose(fp);

}

void PolygonDAO_writePolygonList(PPolygonDAO _this, PPolygon polygonList[], int noe)
{

    remove (_this->filename);

    for (int i = 0; i < noe; i++)
    {
        PolygonDAO_writePolygon(_this, polygonList[i]);
    }

}

PPolygon PolygonDAO_readPolygonHelp(FILE *fp)
{

    int noe = 0;
    fread(&noe,sizeof(int), 1, fp);
    int list[noe][2];



    for (int i = 0; i<noe; i++)
    {
        fread(&list[i][0], sizeof(int), 1, fp);
        fread(&list[i][1], sizeof(int), 1, fp);
    }

    PPolygon pointList = Polygon_create(list, noe);
    return pointList;

}

void PolygonDAO_writePolygonHelp(FILE *fp, PPolygon polygon)
{

    int noe = Polygon_getNoe(polygon);
    fwrite(&noe, sizeof(int), 1, fp);

    for (int i = 0; i < Polygon_getNoe(polygon); i++)
    {
        fwrite (Polygon_getPointAt(polygon, i), Point_getDataSize(), 1, fp);
    }

}

PPolygon PolygonDAO_readFirstPolygon(PPolygonDAO _this)
{

    FILE * fp = fopen(_this->filename, "rb");
    if (!fp)
    {
        printf("Error");
        return NULL;
    }

    PPolygon pointList = PolygonDAO_readPolygonHelp(fp);
    fclose(fp);

    return pointList;

}

PPolygon PolygonDAO_readPolygonAt(PPolygonDAO _this, int index)
{

    FILE * fp = fopen (_this->filename, "rb");

    if (!fp)
    {
        printf("Error");
        return NULL;
    }

    int noePolygon = 0;

    for (int i = 0; i < index; i++)
    {
        noePolygon = 0;
        fread(&noePolygon,sizeof(int), 1, fp);
        fseek(fp, Point_getDataSize()*noePolygon, SEEK_CUR);
    }

    PPolygon p = PolygonDAO_readPolygonHelp(fp);
    fclose(fp);

    return p;

}

PPolygon* PolygonDAO_readAll(PPolygonDAO _this, int *noe)
{

    FILE * fp = fopen(_this->filename, "rb");

    if (!fp)
    {
        printf("Error");
        return NULL;
    }

    fseek(fp, 0, SEEK_SET);
    int polygonCount = 0;

    while (fread(&polygonCount, sizeof(int), 1, fp))
    {
        fseek(fp, Point_getDataSize() * polygonCount, SEEK_CUR);
        (*noe)++;
    }

    PPolygon* polygonList = (PPolygon*)malloc((*noe) * sizeof(PPolygon));

    if (!polygonList)
    {
        printf("Error");
        fclose(fp);
        return NULL;
    }

    fseek(fp, 0, SEEK_SET);

    for (int i = 0; i < *noe; i++)
    {
        polygonList[i] = PolygonDAO_readPolygonAt(_this, i);
    }


    fclose(fp);
    return polygonList;
}

void PolygonDAO_updatePolygonAt(PPolygonDAO _this, int index, PPolygon newPolygon)
{

    FILE *fp = fopen(_this->filename, "r+b");

    if (!fp)
    {
        printf("Error");
        return;
    }

    int noePolygon = 0;
    long offset = 0;

    for (int i = 0; i < index; i++)
    {
        fread(&noePolygon, sizeof(int), 1, fp);
        offset += sizeof(int) + (Point_getDataSize() * noePolygon);
        fseek(fp, offset, SEEK_SET);
    }

    fread(&noePolygon, sizeof(int), 1, fp);

    int newNoe = Polygon_getNoe(newPolygon);
    if (newNoe != noePolygon)
    {
        printf("Error\n");
        fclose(fp);
        return;
    }

    fseek(fp, -(sizeof(int)), SEEK_CUR);
    PolygonDAO_writePolygonHelp(fp, newPolygon);
    fclose(fp);


}

void PolygonDAO_delete(PPolygonDAO _this)
{

    free(_this->filename);
    free(_this);

}
