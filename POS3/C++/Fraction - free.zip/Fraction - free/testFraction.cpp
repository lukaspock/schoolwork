#include <iostream>
#include "Fraction.h"

// Test for operator*
void testOperatorMultiply(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    Fraction result = f1 * f2;
    cout << "Result of multiplication: ";
    result.show();
    cout << endl;
}

// Test for operator==
void testOperatorEqual(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    cout << ((f1 == f2) ? "Equality test passed" : "Equality test failed") << endl;
}

// Test for operator~
void testOperatorReciprocal(int num, int denom) {
    Fraction f(num, denom);
    Fraction reciprocal = ~f;
    cout << "Reciprocal: ";
    reciprocal.show();
    cout << endl;
}

// Test for operator++ (prefix)
void testOperatorPrefixIncrement(int num, int denom) {
    Fraction f(num, denom);
    ++f;
    cout << "After prefix increment: ";
    f.show();
    cout << endl;
}

// Test for operator++ (postfix)
void testOperatorPostfixIncrement(int num, int denom) {
    Fraction f(num, denom);
    Fraction result = f++;
    cout << "After postfix increment (original): ";
    result.show();
    cout << endl;
    cout << "After postfix increment (incremented): ";
    f.show();
    cout << endl;
}

// Test for operator+
void testOperatorAdd(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    Fraction result = f1 + f2;
    cout << "Result of addition: ";
    result.show();
    cout << endl;
}

// Test for operator-
void testOperatorSubtract(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    Fraction result = f1 - f2;
    cout << "Result of subtraction: ";
    result.show();
    cout << endl;
}

// Test for operator/
void testOperatorDivide(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    Fraction result = f1 / f2;
    cout << "Result of division: ";
    result.show();
    cout << endl;
}

// Test for operator<
void testOperatorLessThan(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    cout << ((f1 < f2) ? "Less than test passed" : "Less than test failed") << endl;
}

// Test for operator>
void testOperatorGreaterThan(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    cout << ((f1 > f2) ? "Greater than test passed" : "Greater than test failed") << endl;
}

// Test for operator<=
void testOperatorLessThanOrEqual(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    cout << ((f1 <= f2) ? "Less than or equal test passed" : "Less than or equal test failed") << endl;
}

// Test for operator>=
void testOperatorGreaterThanOrEqual(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    cout << ((f1 >= f2) ? "Greater than or equal test passed" : "Greater than or equal test failed") << endl;
}

// Test for operator!=
void testOperatorNotEqual(int num1, int denom1, int num2, int denom2) {
    Fraction f1(num1, denom1);
    Fraction f2(num2, denom2);
    cout << ((f1 != f2) ? "Not equal test passed" : "Not equal test failed") << endl;
}

// Test for operator-- (prefix)
void testOperatorPrefixDecrement(int num, int denom) {
    Fraction f(num, denom);
    --f;
    cout << "After prefix decrement: ";
    f.show();
    cout << endl;
}

// Test for operator-- (postfix)
void testOperatorPostfixDecrement(int num, int denom) {
    Fraction f(num, denom);
    Fraction result = f--;
    cout << "After postfix decrement (original): ";
    result.show();
    cout << endl;
    cout << "After postfix decrement (decremented): ";
    f.show();
    cout << endl;
}
